# Execution protocol

## 1. Environment

Use Python 3.11 and CUDA 12.4 for the manuscript run. Install the locked packages in a clean environment:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-lock.txt
python -m pip install --no-deps -e .
```

Record `python --version`, `python -m pip freeze`, `nvidia-smi`, and the repository `SHA256SUMS` with every completed run.

## 2. Dataset records and inventory

```bash
python scripts/00_capture_dataset_records.py --config configs/datasets.yaml --download
python scripts/01_build_inventory.py --config configs/tace_moe.yaml
```

The first command captures Kaggle metadata and file lists before download. The second command verifies dataset counts and creates decoded-pixel hashes, DCT perceptual hashes, pair identifiers, file descriptors, and stable anonymous sample identifiers.

## 3. Frozen DINOv2 audit embeddings and groups

```bash
python scripts/02_extract_dinov2_embeddings.py \
  --inventory data/manifests/development_inventory.csv \
  --data-root data/raw/ai_vs_human \
  --output-prefix data/manifests/development_dinov2

python scripts/02_build_groups.py --config configs/tace_moe.yaml
python scripts/03_build_splits.py --config configs/tace_moe.yaml
```

Check these invariants before any training:

- 79,950 development images.
- 39,535 final groups.
- 39,105 groups of size two, 420 groups of size four, and 10 groups of size six.
- Five outer folds with 7,907 groups each.
- Fold image counts of 15,988, 15,990, 15,990, 15,992, and 15,990.
- Zero group overlap between every pair of partition roles.

If any invariant fails, stop and inspect the local snapshot, pairing rule, or duplicate candidates. Do not force the target counts by editing the group file.

## 4. Main nested runs

The full driver trains every fold for each of the five seeds:

```bash
bash reproduce_manuscript.sh
```

For one primary fold:

```bash
python scripts/04_train_fold.py \
  --config configs/tace_moe.yaml \
  --data-root data/raw/ai_vs_human \
  --fold 1 \
  --seed 2026

python scripts/05_fit_temperature.py --run-directory outputs/fold_1/seed_2026
```

Checkpoint selection uses only the selection-partition NLL. Temperature is fitted only on the calibration partition. The outer-test predictions are not read until both operations are frozen.

## 5. Development-only external checkpoint

```bash
python scripts/07_train_external_checkpoint.py \
  --config configs/tace_moe.yaml \
  --data-root data/raw/ai_vs_human \
  --seed 2026

python scripts/08_evaluate_external.py --config configs/tace_moe.yaml --dataset-key external_art
python scripts/08_evaluate_external.py --config configs/tace_moe.yaml --dataset-key external_stress
```

The external images are opened only by the evaluation commands. They do not affect gradients, checkpoint selection, temperature, or threshold.

## 6. Reviewer-requested diagnostics

```bash
python scripts/10_run_robustness.py --config configs/tace_moe.yaml
python scripts/15_descriptor_distributions.py \
  --inventory data/manifests/development_inventory.csv
```

The descriptor command reports class-conditional distributions for dimensions, file size, JPEG quality estimate, JPEG quantization, codec, and EXIF availability. These values audit potential acquisition shortcuts and are never routed into the final model.

## 7. Statistical comparison and tables

```bash
python scripts/11_export_tables.py --config configs/tace_moe.yaml
python scripts/09_cluster_bootstrap.py --config configs/tace_moe.yaml
```

Bootstrap resampling occurs at connected-group level with 10,000 paired replicates and seed 2026. Holm adjustment is applied across the four primary comparisons.

## 8. Final archive audit

```bash
python scripts/12_validate_submission.py --root .
python scripts/14_write_archive_checksums.py --root . --output SHA256SUMS
```

Run the text audit after all logs and manifests have been added. Then create the archive from the repository root without `.git`, downloaded images, caches, checkpoints, or temporary outputs unless the venue permits those files.
