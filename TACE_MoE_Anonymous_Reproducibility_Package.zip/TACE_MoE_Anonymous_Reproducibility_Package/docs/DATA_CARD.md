# Dataset card

## Development dataset

`alessandrasala79/ai-vs-human-generated-dataset` contains 79,950 labeled images: 39,975 AI-generated and 39,975 human-created. It is the only dataset used for parameter fitting, model selection, temperature calibration, and internal cross-validation.

The corpus contains 39,975 documented authentic-generated pairs. Pair, exact-hash, pHash, and frozen DINOv2 edges are merged into connected components before splitting. The target grouping has 39,535 components.

## Primary external dataset

`doctorstrange420/real-and-fake-ai-generated-art-images-dataset` contains 21,642 images balanced between AI art and real art. It is evaluated with the frozen development-only checkpoint, temperature, and 0.5 threshold.

## Stress external dataset

`birdy654/cifake-real-and-ai-generated-synthetic-images` contains 120,000 balanced low-resolution images. It is used as a stress evaluation, not as a second art-domain corpus.

## Snapshot and redistribution policy

The manuscript access date is 19 August 2026. `scripts/00_capture_dataset_records.py` stores the dataset metadata and remote file listing from the authenticated Kaggle environment. `scripts/01_build_inventory.py` stores per-file local checksums and decoded descriptors. Image files are excluded from this archive and remain under source-specific terms.

## Known limitations

- Public-source collection artifacts may remain after threshold-defined duplicate control.
- Generator and editing provenance are incomplete.
- Binary labels do not describe mixed human-AI editing.
- No prompts, subjective ratings, professional review decisions, or post-editing histories are available.
- External datasets differ in style, resolution, compression, and source provenance.
