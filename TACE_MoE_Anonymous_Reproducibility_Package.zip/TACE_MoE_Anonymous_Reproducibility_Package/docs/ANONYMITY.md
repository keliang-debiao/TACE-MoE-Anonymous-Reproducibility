# Anonymous review safeguards

- The archive contains no author name, affiliation, email address, ORCID, grant identifier, private repository URL, workstation path, or source-control history.
- Dataset paths are relative to the repository or supplied at runtime.
- Sample identifiers are derived from dataset key and relative path, then truncated from SHA-256; filenames remain only in local manifests governed by dataset terms.
- Logs included with the archive are generated in the delivery environment and do not contain user names or host-specific absolute paths.
- `scripts/12_validate_submission.py` scans text and filenames for prohibited drafting labels, local absolute paths, and email addresses.
- The neutral copyright holder is `Anonymous Authors` for review. Replace it only after acceptance if required by the venue.
- The package does not contain `.git`, remote URLs, issue references, commit authors, or timestamps that identify contributors.
