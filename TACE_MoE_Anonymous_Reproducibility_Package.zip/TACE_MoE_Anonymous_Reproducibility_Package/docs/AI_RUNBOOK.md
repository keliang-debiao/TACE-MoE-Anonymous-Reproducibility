# AI-assisted execution runbook

This runbook is intended for an AI coding agent operating in a clean clone. The agent must treat scientific outputs as immutable evidence produced by executed commands, not as values to be copied from the manuscript-target tables.

## Operating rules

1. Read `README.md`, `configs/tace_moe.yaml`, and `docs/OUTPUT_CONTRACT.md` before running commands.
2. Never change thresholds, seeds, split roles, metric definitions, or dataset roots without recording a new configuration file.
3. Never use external images for fitting, selection, calibration, or threshold choice.
4. Stop on any count mismatch, cross-role group overlap, non-finite loss, missing checkpoint, or prediction-row mismatch.
5. Preserve raw command logs, resolved configuration, environment inventory, temperatures, and checksum files.
6. Compare computed results with manuscript targets only after the run is complete.

## Phase A: repository verification

Run:

```bash
bash run_repository_validation.sh
```

Required terminal state:

- unit tests pass;
- repository validation prints `VALIDATION_STATUS=PASS`;
- submission text audit prints `SUBMISSION_TEXT_AUDIT=PASS` when invoked;
- `SHA256SUMS` is regenerated.

## Phase B: data freeze

Run the dataset record capture, inventory, DINOv2 extraction, group construction, and split construction commands in `docs/EXECUTION.md`. Report the exact counts and halt if they differ from the invariants.

Required evidence to retain:

- Kaggle metadata JSON and file listing for each source;
- decoded-pixel SHA-256 values;
- pHash values;
- DINOv2 embedding file and aligned identifier list;
- edge list with criterion and measured value;
- connected-component manifest;
- fold-role manifest and zero-overlap audit.

## Phase C: training

Execute seed 2026 first. For every fold, inspect:

- the first batch for finite tensors and balanced labels;
- training and selection losses for finiteness;
- best epoch and selection NLL;
- calibration temperature positivity;
- one and only one prediction row per held-out image;
- probabilities within [0,1] and router weights summing to one.

Only after all five primary folds pass should seeds 2027-2030 be scheduled. Do not substitute a successful fold for a failed fold.

## Phase D: aggregation and external evaluation

Concatenate outer-test predictions by stable `sample_id`, not by dataloader order. Confirm every development sample appears in the pooled primary output exactly once. Train the external checkpoint from the complete development corpus using a fresh 80/10/10 group partition, then freeze it before either external root is opened.

## Phase E: diagnostic analyses

Run and archive:

- metadata-versus-pixel-statistics router ablation;
- component ablations;
- loss-weight sensitivity;
- Brier-by-temperature factorial calibration analysis;
- nine clean or perturbed conditions;
- correct-versus-incorrect routing summaries;
- reliability-bin exports;
- composite confidence risk-coverage outputs;
- paired cluster bootstrap comparisons;
- descriptor class distributions.

## Phase F: discrepancy handling

When a computed value differs from a manuscript target, report:

- metric and target;
- computed value;
- absolute difference;
- configuration checksum;
- data snapshot checksum;
- fold, seed, checkpoint epoch, and temperature;
- whether the difference exceeds normal floating-point or stochastic variation.

Do not overwrite computed outputs. Store every rerun in a new directory and state the technical cause before recommending a manuscript update.
