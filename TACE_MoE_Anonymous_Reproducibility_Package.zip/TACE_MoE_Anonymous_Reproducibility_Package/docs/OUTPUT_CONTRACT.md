# Output contract

Every scientific output is keyed by stable anonymous sample identifiers and must be derivable from input manifests, frozen configuration, and saved model state.

## Checkpoint directory

Each `outputs/fold_{k}/seed_{s}/` directory contains:

| File | Required content |
|---|---|
| `best_checkpoint.pt` | Model state, best epoch, selection NLL, seed, and resolved configuration |
| `training_history.csv` | Per-epoch training components, selection metrics, learning rate, and checkpoint flag |
| `selection_uncalibrated.csv` | Selection logits and diagnostics |
| `calibration_uncalibrated.csv` | Independent calibration logits and diagnostics |
| `test_uncalibrated.csv` | Untouched outer-test logits and diagnostics |
| `temperature.json` | Positive fitted scalar and its logarithm |
| `test_calibrated.csv` | Frozen calibrated outer-test probabilities |
| `test_calibrated.metrics.json` | Discrimination and calibration metrics |
| `resolved_config.yaml` | Exact run configuration |
| `run_provenance.json` | Device, software, parameter count, seed, and best epoch |

Prediction CSV files contain:

`sample_id, group_id, label, logit, probability, confidence, router_rgb, router_npr, router_frequency, expert_rgb, expert_npr, expert_frequency, entropy_rgb, entropy_npr, entropy_frequency`

Calibrated files additionally retain `probability_uncalibrated`.

## Metrics

- Accuracy, precision, recall, and F1 use threshold 0.5.
- AUROC and AUPRC use continuous calibrated probabilities.
- NLL clips probabilities to [1e-7, 1-1e-7].
- Brier is mean squared probability error.
- ECE uses 15 fixed equal-width bins.
- Adaptive ECE uses 15 equal-frequency bins.
- Class-wise ECE averages positive-class and negative-class equal-width ECE.
- AURC is trapezoidal area under empirical risk versus retained coverage.

## Statistical outputs

Paired comparisons require identical `sample_id` order after sorting. Connected `group_id` values are resampled with replacement, retaining every image in each sampled group. The archive records point estimate, percentile 95% interval, raw two-sided p value, Holm-adjusted p value, seed, and valid replicate count.

## Target separation

`artifacts/manuscript_targets/` contains values transcribed from the paper for comparison. Programs must never read those files during training, calibration, inference, bootstrap resampling, or aggregation.
