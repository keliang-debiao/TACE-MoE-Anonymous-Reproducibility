# TACE-MoE model card

## Intended task

Binary assessment of whether a visual image is AI-generated or human-created. The output is a calibrated AI-class probability, a thresholded prediction, three expert probabilities, three routing weights, and an algorithmic confidence score.

## Architecture

- RGB stream: ImageNet-1K pretrained ConvNeXt-T, fully fine-tuned, projected from 768 to 256 dimensions.
- NPR stream: deterministic radius-two nearest-RGB-neighbor residual followed by an independent four-stage CNN with widths 48, 96, 192, and 384, then a 256-dimensional projection.
- Frequency stream: one-level Haar LH, HL, and HH maps for each RGB channel, standardized using fitting-partition statistics, followed by the same CNN layout and a 256-dimensional projection.
- Experts: one 256-to-1 head per stream; Bernoulli entropies are supplied to the router.
- Router: 777 inputs, 128 hidden units, GELU, dropout 0.20, and three softmax weights. Inputs are three representations, three expert entropies, and six crop-derived RGB statistics.
- Fusion: weighted sum of three learned 256-dimensional value projections and one final linear head.
- Calibration: one positive temperature fitted on an independent development partition.

## Objective

Fused BCE plus 0.30 expert BCE, 0.10 ordered cross-evidence contrastive loss, 0.05 class-conditional mean discrepancy, and 0.05 Brier regularization.

## Intended use limits

The detector is an authenticity-screening research system. It is not validated for author attribution, plagiarism adjudication, legal evidence, surveillance, or fully automated sanctions. The confidence score measures model error ranking, not human trust. External artistic style, generator family, editing, screenshot capture, and recompression can materially reduce reliability.

## Reported performance target

The primary internal target is 0.975 ± 0.003 F1, 0.996 ± 0.001 AUROC, and 0.019 ± 0.002 ECE. The Real/Fake AI Art target is 0.887 F1, 0.945 AUROC, and 0.045 ECE. These are manuscript-reported targets, not values produced by repository validation.
