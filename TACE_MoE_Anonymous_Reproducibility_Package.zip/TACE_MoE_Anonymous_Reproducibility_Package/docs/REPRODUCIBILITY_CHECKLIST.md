# Reproducibility checklist

## Code and environment

- [x] Locked Python dependencies.
- [x] Conda and Docker environment specifications.
- [x] Deterministic seed setup and dataloader worker seeding.
- [x] Full manuscript model and objective implementation.
- [x] CPU repository validation configuration.
- [x] Unit and integration tests.
- [x] Archive-wide SHA-256 generation.

## Data and leakage control

- [x] Public dataset handles and access date.
- [x] Automated Kaggle metadata and file-list capture.
- [x] Per-image decoded-pixel SHA-256 and 64-bit pHash.
- [x] Frozen DINOv2 audit embedding extraction.
- [x] Connected-component grouping across pair, hash, pHash, and embedding edges.
- [x] Nested group-disjoint partition construction and audit.
- [x] External-overlap audit functions.
- [x] Class-conditional file-descriptor distribution export.
- [ ] Actual dataset metadata and image checksum manifests must be generated from the authorized snapshots used by the submitting authors.

## Training and calibration

- [x] Five-fold outer evaluation.
- [x] Disjoint fit, selection, and calibration roles.
- [x] Five fixed training seeds.
- [x] Selection by independent NLL.
- [x] Development-only L-BFGS temperature fitting.
- [x] Fixed threshold 0.5.
- [x] Development-only external checkpoint.

## Evaluation and analysis

- [x] Accuracy, precision, recall, F1, AUROC, and AUPRC.
- [x] NLL, Brier, equal-width ECE, adaptive ECE, and class-wise ECE.
- [x] Reliability-bin and risk-coverage exports.
- [x] Cluster-level paired bootstrap and Holm correction.
- [x] Eight perturbations plus clean evaluation.
- [x] Router weights, expert probabilities, entropies, and confidence outputs.
- [x] Machine-readable manuscript target tables.
- [ ] Manuscript-scale checkpoints and raw predictions must be generated on the three dataset snapshots; they are not represented by the included repository-validation logs.
