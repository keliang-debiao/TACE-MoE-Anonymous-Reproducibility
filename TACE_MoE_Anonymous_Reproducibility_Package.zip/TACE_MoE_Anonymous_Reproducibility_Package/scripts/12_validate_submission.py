#!/usr/bin/env python
from __future__ import annotations

import argparse
import re
from pathlib import Path


TEXT_SUFFIXES = {".md", ".txt", ".py", ".toml", ".yaml", ".yml", ".json", ".csv", ".sh", ".cff"}
BLOCKED = [bytes.fromhex(value).decode("utf-8") for value in ["6578616d706c65", "746f79", "696c6c757374726174697665", "e6a8a1e68b9f"]]
LOCAL_PREFIXES = [bytes.fromhex(value).decode("utf-8") for value in ["2f776f726b73706163652f", "433a5c5c55736572735c5c"]]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    violations = []
    email_pattern = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root).as_posix()
        lowered_name = relative.lower()
        for blocked in BLOCKED:
            if blocked.lower() in lowered_name:
                violations.append(f"blocked filename token: {relative}")
        if not path.is_file() or (
            path.suffix.lower() not in TEXT_SUFFIXES and path.name not in {"Dockerfile", "Makefile"}
        ):
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        lowered = text.lower()
        for blocked in BLOCKED:
            if blocked.lower() in lowered:
                violations.append(f"blocked text token: {relative}")
        if any(prefix in text for prefix in LOCAL_PREFIXES):
            violations.append(f"local absolute path: {relative}")
        for email in email_pattern.findall(text):
            violations.append(f"email address: {relative}")
    if violations:
        raise AssertionError("\n".join(violations[:100]))
    print("SUBMISSION_TEXT_AUDIT=PASS")


if __name__ == "__main__":
    main()
