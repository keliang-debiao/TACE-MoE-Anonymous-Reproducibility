#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch
import yaml

from tace_moe.calibration import TemperatureScaler
from tace_moe.metrics import binary_metrics
from tace_moe.model import TACEMoE
from tace_moe.robustness import apply_condition
from tace_moe.training import make_loader


CONDITIONS = ["clean", "jpeg70", "noise", "occlusion", "down_up", "center_crop", "blur", "screenshot", "social_media"]


@torch.inference_mode()
def evaluate_condition(model, loader, device, condition, robust_config, seed, temperature):
    labels, probabilities = [], []
    for batch_index, batch in enumerate(loader):
        pixels = apply_condition(batch["pixels"].to(device), condition, robust_config, seed + batch_index)
        output = model(pixels)
        labels.extend(batch["label"].numpy().astype(int).tolist())
        probabilities.extend(temperature.predict_proba(output["logits"].cpu().numpy()).tolist())
    return binary_metrics(labels, probabilities)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--dataset-config", default="configs/datasets.yaml")
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    data_config = yaml.safe_load(Path(args.dataset_config).read_text(encoding="utf-8"))
    inventory = pd.read_csv(config["paths"]["group_manifest"])
    split_manifest = pd.read_csv(config["paths"]["fold_manifest"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    rows = []
    for fold in range(1, int(config["study"]["outer_folds"]) + 1):
        split = split_manifest[(split_manifest["outer_fold"] == fold) & (split_manifest["role"] == "test")]
        frame = split[["sample_id"]].merge(inventory, on="sample_id", validate="one_to_one")
        loader = make_loader(
            frame,
            data_config["datasets"]["development"]["root"],
            config["preprocessing"],
            False,
            int(config["training"]["batch_size"]),
            int(config["training"]["num_workers"]),
            args.seed + fold,
        )
        run_directory = Path(config["paths"]["output_root"]) / f"fold_{fold}" / f"seed_{args.seed}"
        checkpoint = torch.load(run_directory / "best_checkpoint.pt", map_location=device, weights_only=False)
        model = TACEMoE(config).to(device)
        model.load_state_dict(checkpoint["model_state"])
        model.eval()
        temperature = TemperatureScaler.from_dict(
            json.loads((run_directory / "temperature.json").read_text(encoding="utf-8"))
        )
        for condition in CONDITIONS:
            metrics = evaluate_condition(
                model, loader, device, condition, config["robustness"], args.seed + fold * 100, temperature
            )
            rows.append({"outer_fold": fold, "condition": condition, **metrics})
            print(json.dumps(rows[-1], sort_keys=True), flush=True)
    output = Path(config["paths"]["output_root"]) / "robustness" / "fold_metrics.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)


if __name__ == "__main__":
    main()
