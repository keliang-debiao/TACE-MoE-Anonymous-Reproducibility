#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import yaml

from tace_moe.audit import audit_cross_partition_overlap
from tace_moe.splits import build_nested_split_manifest, split_summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    grouped = pd.read_csv(config["paths"]["group_manifest"])
    manifest = build_nested_split_manifest(
        grouped, int(config["study"]["outer_folds"]), int(config["study"]["split_seed"])
    )
    output = Path(config["paths"]["fold_manifest"])
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest.to_csv(output, index=False)
    split_summary(manifest).to_csv(output.with_name("development_fold_summary.csv"), index=False)
    audit = audit_cross_partition_overlap(manifest)
    audit.to_csv(output.with_name("development_fold_overlap_audit.csv"), index=False)
    if int(audit["overlap_groups"].max()) != 0:
        raise AssertionError("Cross-role group overlap detected")
    print("FOLD_AUDIT=PASS")


if __name__ == "__main__":
    main()
