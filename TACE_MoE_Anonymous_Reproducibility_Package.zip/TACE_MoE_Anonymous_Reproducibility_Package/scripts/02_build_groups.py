#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from tace_moe.audit import (
    connected_group_manifest,
    exact_hash_edges,
    pair_edges,
    threshold_edges_blockwise,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--embedding-prefix", default="data/manifests/development_dinov2")
    parser.add_argument("--block-size", type=int, default=2048)
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    inventory = pd.read_csv(config["paths"]["development_inventory"])
    identifiers = inventory["sample_id"].astype(str).tolist()
    hashes = inventory["phash64"].astype("uint64").to_numpy()
    embedding_path = Path(args.embedding_prefix).with_suffix(".npy")
    identifier_path = Path(args.embedding_prefix).with_suffix(".csv")
    embeddings = None
    if embedding_path.exists() and identifier_path.exists():
        embedding_ids = pd.read_csv(identifier_path)["sample_id"].astype(str).tolist()
        if embedding_ids != identifiers:
            raise ValueError("Embedding identifiers do not match inventory order")
        embeddings = np.load(embedding_path, mmap_mode="r")
    edges = pair_edges(inventory) + exact_hash_edges(inventory)
    edges.extend(
        threshold_edges_blockwise(
            identifiers,
            hashes,
            embeddings,
            int(config["audit"]["phash_hamming_max"]),
            float(config["audit"]["embedding_cosine_min"]),
            args.block_size,
        )
    )
    grouped = connected_group_manifest(inventory, edges)
    output = Path(config["paths"]["group_manifest"])
    grouped.to_csv(output, index=False)
    pd.DataFrame([edge.__dict__ for edge in edges]).to_csv(output.with_name("development_group_edges.csv"), index=False)
    sizes = grouped.groupby("group_id").size().value_counts().sort_index()
    print(f"FINAL_GROUPS={grouped['group_id'].nunique()}")
    print("GROUP_SIZE_COUNTS=" + ",".join(f"{size}:{count}" for size, count in sizes.items()))


if __name__ == "__main__":
    main()
