#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path

import yaml


def run_command(arguments: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(arguments, check=True, text=True, capture_output=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    if shutil.which("kaggle") is None:
        raise RuntimeError("Kaggle CLI is not installed")
    record_root = Path(config["record_root"])
    record_root.mkdir(parents=True, exist_ok=True)
    captured: list[dict[str, str]] = []
    for key, dataset in config["datasets"].items():
        handle = dataset["kaggle_handle"]
        target = record_root / key
        target.mkdir(parents=True, exist_ok=True)
        metadata = run_command(["kaggle", "datasets", "metadata", "-d", handle, "-p", str(target)])
        files = run_command(["kaggle", "datasets", "files", handle, "--csv"])
        (target / "files.csv").write_text(files.stdout, encoding="utf-8")
        (target / "metadata_command.txt").write_text(" ".join(metadata.args) + "\n", encoding="utf-8")
        if args.download:
            root = Path(dataset["root"])
            root.mkdir(parents=True, exist_ok=True)
            run_command(["kaggle", "datasets", "download", "-d", handle, "-p", str(root), "--unzip"])
        captured.append({"key": key, "handle": handle, "access_date": config["snapshot_access_date"]})
    (record_root / "capture_index.json").write_text(
        json.dumps(captured, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"CAPTURED_DATASET_RECORDS={len(captured)}")


if __name__ == "__main__":
    main()
