#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import yaml

from tace_moe.bootstrap import holm_adjust, paired_cluster_bootstrap


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--tace", default="outputs/aggregated/tace_internal.csv")
    parser.add_argument("--baseline", default="outputs/aggregated/rgb_npr_internal.csv")
    parser.add_argument("--output", default="outputs/statistics/tace_vs_rgb_npr.json")
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    tace = pd.read_csv(args.tace).sort_values("sample_id").reset_index(drop=True)
    baseline = pd.read_csv(args.baseline).sort_values("sample_id").reset_index(drop=True)
    if not tace["sample_id"].equals(baseline["sample_id"]):
        raise ValueError("Paired predictions do not contain the same ordered samples")
    results = {}
    p_values = []
    for metric in ("accuracy", "f1", "auroc", "ece"):
        result = paired_cluster_bootstrap(
            tace["label"].to_numpy(),
            tace["probability"].to_numpy(),
            baseline["probability"].to_numpy(),
            tace["group_id"].to_numpy(),
            metric,
            int(config["statistics"]["bootstrap_replicates"]),
            int(config["statistics"]["bootstrap_seed"]),
        )
        results[metric] = result
        p_values.append(result["p_value"])
    for metric, adjusted in zip(results, holm_adjust(p_values)):
        results[metric]["p_value_holm"] = adjusted
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(results, sort_keys=True))


if __name__ == "__main__":
    main()
