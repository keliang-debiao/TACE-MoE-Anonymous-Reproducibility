#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from PIL import Image, ImageOps
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

from tace_moe.data import center_crop, image_to_tensor, resize_shorter_side


class AuditDataset(Dataset):
    def __init__(self, inventory: pd.DataFrame, root: Path) -> None:
        self.inventory = inventory.reset_index(drop=True)
        self.root = root

    def __len__(self) -> int:
        return len(self.inventory)

    def __getitem__(self, index: int):
        row = self.inventory.iloc[index]
        with Image.open(self.root / row["relative_path"]) as source:
            image = ImageOps.exif_transpose(source).convert("RGB")
        image = center_crop(resize_shorter_side(image, 256), 224)
        tensor = image_to_tensor(image)
        tensor = (tensor - torch.tensor([0.485, 0.456, 0.406])[:, None, None]) / torch.tensor(
            [0.229, 0.224, 0.225]
        )[:, None, None]
        return tensor, str(row["sample_id"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--output-prefix", required=True)
    parser.add_argument("--model", default="vit_base_patch14_dinov2.lvd142m")
    parser.add_argument("--batch-size", type=int, default=64)
    args = parser.parse_args()
    import timm

    inventory = pd.read_csv(args.inventory)
    dataset = AuditDataset(inventory, Path(args.data_root))
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=8, pin_memory=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = timm.create_model(args.model, pretrained=True, num_classes=0, global_pool="avg").to(device).eval()
    embeddings, identifiers = [], []
    with torch.inference_mode():
        for pixels, sample_ids in tqdm(loader, desc="DINOv2 audit embeddings"):
            value = torch.nn.functional.normalize(model(pixels.to(device)), dim=1)
            embeddings.append(value.cpu().numpy().astype(np.float32))
            identifiers.extend(sample_ids)
    prefix = Path(args.output_prefix)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    np.save(prefix.with_suffix(".npy"), np.concatenate(embeddings))
    pd.DataFrame({"sample_id": identifiers}).to_csv(prefix.with_suffix(".csv"), index=False)
    print(f"EMBEDDINGS={len(identifiers)}")


if __name__ == "__main__":
    main()
