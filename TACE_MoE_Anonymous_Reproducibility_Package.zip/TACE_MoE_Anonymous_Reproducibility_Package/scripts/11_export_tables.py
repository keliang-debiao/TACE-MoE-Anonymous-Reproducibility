#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import yaml

from tace_moe.metrics import binary_metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    output_root = Path(config["paths"]["output_root"])
    frames, rows = [], []
    for fold in range(1, int(config["study"]["outer_folds"]) + 1):
        path = output_root / f"fold_{fold}" / f"seed_{args.seed}" / "test_calibrated.csv"
        frame = pd.read_csv(path)
        frame["outer_fold"] = fold
        frames.append(frame)
        rows.append({"outer_fold": fold, **binary_metrics(frame["label"], frame["probability"])})
    aggregated = pd.concat(frames, ignore_index=True)
    aggregate_directory = output_root / "aggregated"
    aggregate_directory.mkdir(parents=True, exist_ok=True)
    aggregated.to_csv(aggregate_directory / "tace_internal.csv", index=False)
    fold_metrics = pd.DataFrame(rows)
    fold_metrics.to_csv(aggregate_directory / "tace_internal_fold_metrics.csv", index=False)
    summary = fold_metrics.drop(columns="outer_fold").agg(["mean", "std"]).T.reset_index(names="metric")
    summary.to_csv(aggregate_directory / "tace_internal_summary.csv", index=False)
    baseline_models = [
        "logistic_regression",
        "random_forest",
        "xgboost",
        "mlp",
        "resnet50",
        "convnext_tiny",
        "vit_base_patch16_224",
        "dinov2_b14_linear",
        "siglip2_b16_224_linear",
        "rgb_npr",
    ]
    baseline_summaries = []
    for model in baseline_models:
        model_frames = []
        for fold in range(1, int(config["study"]["outer_folds"]) + 1):
            path = output_root / "baselines" / model / f"fold_{fold}" / f"seed_{args.seed}" / "test_calibrated.csv"
            if path.exists():
                value = pd.read_csv(path)
                value["outer_fold"] = fold
                model_frames.append(value)
        if len(model_frames) != int(config["study"]["outer_folds"]):
            continue
        pooled = pd.concat(model_frames, ignore_index=True)
        pooled.to_csv(aggregate_directory / f"{model}_internal.csv", index=False)
        baseline_summaries.append({"model": model, **binary_metrics(pooled["label"], pooled["probability"])})
    if baseline_summaries:
        pd.DataFrame(baseline_summaries).to_csv(
            aggregate_directory / "baseline_internal_summary.csv", index=False
        )
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
