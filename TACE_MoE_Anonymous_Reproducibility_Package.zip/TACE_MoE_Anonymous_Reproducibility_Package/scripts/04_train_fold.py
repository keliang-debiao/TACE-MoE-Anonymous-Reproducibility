#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import yaml

from tace_moe.training import run_training


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--fold", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--split-manifest")
    parser.add_argument("--run-directory")
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    inventory = pd.read_csv(config["paths"]["group_manifest"])
    split_path = args.split_manifest or config["paths"]["fold_manifest"]
    split = pd.read_csv(split_path)
    if "outer_fold" in split.columns:
        split = split[split["outer_fold"] == args.fold]
    run_directory = args.run_directory or f"{config['paths']['output_root']}/fold_{args.fold}/seed_{args.seed}"
    run_training(config, inventory, split, args.data_root, run_directory, args.seed)


if __name__ == "__main__":
    main()
