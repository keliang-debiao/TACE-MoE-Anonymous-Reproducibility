#!/usr/bin/env python
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    output = Path(args.output).resolve()
    lines = []
    for path in sorted(value for value in root.rglob("*") if value.is_file()):
        if path == output or "__pycache__" in path.parts or ".pytest_cache" in path.parts:
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(root).as_posix()}")
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"CHECKSUM_FILES={len(lines)}")


if __name__ == "__main__":
    main()
