#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, mannwhitneyu


NUMERIC_FIELDS = [
    "width",
    "height",
    "byte_size",
    "jpeg_quality_estimate",
    "jpeg_quantization_mean",
]
CATEGORICAL_FIELDS = ["codec", "exif_available"]


def standardized_mean_difference(left: pd.Series, right: pd.Series) -> float:
    left = left.dropna().astype(float)
    right = right.dropna().astype(float)
    pooled = np.sqrt((left.var(ddof=1) + right.var(ddof=1)) / 2.0)
    return float((right.mean() - left.mean()) / pooled) if pooled > 0 else 0.0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--output-directory", default="outputs/descriptor_audit")
    args = parser.parse_args()
    frame = pd.read_csv(args.inventory)
    output = Path(args.output_directory)
    output.mkdir(parents=True, exist_ok=True)
    summaries = []
    tests = []
    for field in NUMERIC_FIELDS:
        for label, class_name in [(0, "human"), (1, "ai")]:
            values = frame.loc[frame["label"] == label, field].dropna().astype(float)
            summaries.append(
                {
                    "field": field,
                    "class": class_name,
                    "count": len(values),
                    "mean": values.mean(),
                    "standard_deviation": values.std(ddof=1),
                    "median": values.median(),
                    "q1": values.quantile(0.25),
                    "q3": values.quantile(0.75),
                }
            )
        human = frame.loc[frame["label"] == 0, field].dropna().astype(float)
        ai = frame.loc[frame["label"] == 1, field].dropna().astype(float)
        statistic, p_value = mannwhitneyu(human, ai, alternative="two-sided")
        tests.append(
            {
                "field": field,
                "test": "Mann-Whitney U",
                "statistic": statistic,
                "p_value": p_value,
                "standardized_mean_difference_ai_minus_human": standardized_mean_difference(human, ai),
            }
        )
    for field in CATEGORICAL_FIELDS:
        table = pd.crosstab(frame[field].fillna("missing"), frame["label"])
        statistic, p_value, _, _ = chi2_contingency(table)
        table.reset_index().to_csv(output / f"{field}_counts.csv", index=False)
        tests.append(
            {
                "field": field,
                "test": "chi-square",
                "statistic": statistic,
                "p_value": p_value,
                "standardized_mean_difference_ai_minus_human": np.nan,
            }
        )
    pd.DataFrame(summaries).to_csv(output / "numeric_class_distributions.csv", index=False)
    pd.DataFrame(tests).to_csv(output / "distribution_tests.csv", index=False)
    print(f"DESCRIPTOR_FIELDS={len(NUMERIC_FIELDS) + len(CATEGORICAL_FIELDS)}")


if __name__ == "__main__":
    main()
