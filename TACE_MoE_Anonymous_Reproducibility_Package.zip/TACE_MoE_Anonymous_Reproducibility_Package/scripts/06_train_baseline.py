#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import yaml

from tace_moe.baselines import build_image_baseline
from tace_moe.calibration import TemperatureScaler
from tace_moe.metrics import binary_metrics
from tace_moe.seed import seed_everything
from tace_moe.training import make_loader


FEATURE_MODELS = {"logistic_regression", "random_forest", "xgboost", "mlp"}


def logit_from_probability(probability: np.ndarray) -> np.ndarray:
    value = np.clip(probability, 1e-7, 1 - 1e-7)
    return np.log(value / (1 - value))


def fit_feature_model(name: str, features: np.ndarray, labels: np.ndarray, seed: int):
    if name == "logistic_regression":
        from sklearn.linear_model import LogisticRegression

        model = LogisticRegression(C=1.0, max_iter=2000, random_state=seed)
    elif name == "random_forest":
        from sklearn.ensemble import RandomForestClassifier

        model = RandomForestClassifier(n_estimators=500, max_features="sqrt", n_jobs=-1, random_state=seed)
    elif name == "xgboost":
        from xgboost import XGBClassifier

        model = XGBClassifier(
            n_estimators=500,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric="logloss",
            random_state=seed,
            n_jobs=-1,
        )
    elif name == "mlp":
        from sklearn.neural_network import MLPClassifier

        model = MLPClassifier(hidden_layer_sizes=(256,), max_iter=200, early_stopping=True, random_state=seed)
    else:
        raise KeyError(name)
    return model.fit(features, labels)


def run_feature_baseline(args, inventory, split, run_directory):
    feature_ids = pd.read_csv(Path(args.feature_prefix).with_suffix(".csv"))["sample_id"].astype(str)
    features = np.load(Path(args.feature_prefix).with_suffix(".npy"), mmap_mode="r")
    index = {sample_id: position for position, sample_id in enumerate(feature_ids)}
    merged = split[["sample_id", "role"]].merge(
        inventory[["sample_id", "label", "group_id"]], on="sample_id"
    )
    fit = merged[merged["role"] == "fit"]
    model = fit_feature_model(
        args.model,
        np.asarray(features[[index[value] for value in fit["sample_id"].astype(str)]]),
        fit["label"].to_numpy(),
        args.seed,
    )
    role_frames = {}
    for role in ["selection", "calibration", "test"]:
        part = merged[merged["role"] == role].copy()
        if part.empty:
            continue
        probability = model.predict_proba(
            np.asarray(features[[index[value] for value in part["sample_id"].astype(str)]])
        )[:, 1]
        part["logit"] = logit_from_probability(probability)
        part["probability"] = probability
        role_frames[role] = part
    scaler = TemperatureScaler().fit(
        role_frames["calibration"]["logit"], role_frames["calibration"]["label"]
    )
    for role, frame in role_frames.items():
        frame["probability_uncalibrated"] = frame["probability"]
        frame["probability"] = scaler.predict_proba(frame["logit"])
        frame.to_csv(run_directory / f"{role}_calibrated.csv", index=False)
    (run_directory / "temperature.json").write_text(
        json.dumps(scaler.to_dict(), indent=2) + "\n", encoding="utf-8"
    )


@torch.inference_mode()
def image_predictions(model, loader, device):
    rows = []
    model.eval()
    for batch in loader:
        output = model(batch["pixels"].to(device))
        for index, sample_id in enumerate(batch["sample_id"]):
            rows.append(
                {
                    "sample_id": sample_id,
                    "group_id": batch["group_id"][index],
                    "label": int(batch["label"][index]),
                    "logit": float(output["logits"][index].cpu()),
                    "probability": float(output["probability"][index].cpu()),
                    "confidence": float(output["confidence"][index].cpu()),
                }
            )
    return pd.DataFrame(rows)


def run_image_baseline(args, config, inventory, split, run_directory):
    merged = split[["sample_id", "role"]].merge(inventory, on="sample_id")
    loaders = {
        role: make_loader(
            merged[merged["role"] == role],
            args.data_root,
            config["preprocessing"],
            role == "fit",
            int(config["training"]["batch_size"]),
            int(config["training"]["num_workers"]),
            args.seed + offset,
        )
        for offset, role in enumerate(["fit", "selection", "calibration", "test"])
        if (merged["role"] == role).any()
    }
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_image_baseline(args.model, config).to(device)
    optimizer = torch.optim.AdamW(
        [value for value in model.parameters() if value.requires_grad],
        lr=float(config["training"]["maximum_learning_rate"]),
        weight_decay=float(config["training"]["weight_decay"]),
    )
    best_nll, bad_epochs = float("inf"), 0
    for epoch in range(1, int(config["training"]["epochs"]) + 1):
        model.train()
        for batch in loaders["fit"]:
            labels = batch["label"].to(device)
            optimizer.zero_grad(set_to_none=True)
            output = model(batch["pixels"].to(device))
            loss = F.binary_cross_entropy_with_logits(output["logits"], labels)
            loss.backward()
            optimizer.step()
        selection = image_predictions(model, loaders["selection"], device)
        nll = binary_metrics(selection["label"], selection["probability"])["nll"]
        print(json.dumps({"epoch": epoch, "selection_nll": nll}), flush=True)
        if nll < best_nll:
            best_nll, bad_epochs = nll, 0
            torch.save({"model_state": model.state_dict(), "epoch": epoch}, run_directory / "best_checkpoint.pt")
        else:
            bad_epochs += 1
        if bad_epochs >= int(config["training"]["early_stopping_patience"]):
            break
    model.load_state_dict(
        torch.load(run_directory / "best_checkpoint.pt", map_location=device, weights_only=False)["model_state"]
    )
    frames = {
        role: image_predictions(model, loader, device)
        for role, loader in loaders.items()
        if role != "fit"
    }
    scaler = TemperatureScaler().fit(frames["calibration"]["logit"], frames["calibration"]["label"])
    for role, frame in frames.items():
        frame["probability_uncalibrated"] = frame["probability"]
        frame["probability"] = scaler.predict_proba(frame["logit"])
        frame.to_csv(run_directory / f"{role}_calibrated.csv", index=False)
    (run_directory / "temperature.json").write_text(
        json.dumps(scaler.to_dict(), indent=2) + "\n", encoding="utf-8"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--fold", type=int, required=True)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--data-root", default="data/raw/ai_vs_human")
    parser.add_argument("--feature-prefix", default="data/manifests/development_dinov2")
    parser.add_argument("--split-manifest")
    parser.add_argument("--run-directory")
    args = parser.parse_args()
    seed_everything(args.seed)
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    inventory = pd.read_csv(config["paths"]["group_manifest"])
    split = pd.read_csv(args.split_manifest or config["paths"]["fold_manifest"])
    if "outer_fold" in split.columns:
        split = split[split["outer_fold"] == args.fold]
    run_directory = Path(args.run_directory) if args.run_directory else (
        Path(config["paths"]["output_root"])
        / "baselines"
        / args.model
        / f"fold_{args.fold}"
        / f"seed_{args.seed}"
    )
    run_directory.mkdir(parents=True, exist_ok=True)
    if args.model in FEATURE_MODELS:
        run_feature_baseline(args, inventory, split, run_directory)
    else:
        run_image_baseline(args, config, inventory, split, run_directory)
    print(f"BASELINE_COMPLETE={args.model}:fold_{args.fold}:seed_{args.seed}")


if __name__ == "__main__":
    main()
