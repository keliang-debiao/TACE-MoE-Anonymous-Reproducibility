#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import yaml

from tace_moe.calibration import TemperatureScaler
from tace_moe.splits import _best_group_holdout
from tace_moe.training import run_training


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    inventory = pd.read_csv(config["paths"]["group_manifest"])
    fit_indices, held_indices = _best_group_holdout(inventory, 0.20, args.seed)
    held = inventory.iloc[held_indices].reset_index(drop=True)
    selection_indices, calibration_indices = _best_group_holdout(held, 0.50, args.seed + 500)
    roles = pd.DataFrame({"sample_id": inventory["sample_id"], "role": "fit"})
    roles.loc[roles["sample_id"].isin(held.iloc[selection_indices]["sample_id"]), "role"] = "selection"
    roles.loc[roles["sample_id"].isin(held.iloc[calibration_indices]["sample_id"]), "role"] = "calibration"
    run_directory = Path(config["paths"]["output_root"]) / "external_checkpoint" / f"seed_{args.seed}"
    run_directory.mkdir(parents=True, exist_ok=True)
    roles.to_csv(run_directory / "development_roles.csv", index=False)
    run_training(config, inventory, roles, args.data_root, run_directory, args.seed)
    calibration = pd.read_csv(run_directory / "calibration_uncalibrated.csv")
    scaler = TemperatureScaler().fit(
        calibration["logit"].to_numpy(),
        calibration["label"].to_numpy(),
        int(config["calibration"]["maximum_iterations"]),
    )
    (run_directory / "temperature.json").write_text(
        json.dumps(scaler.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"EXTERNAL_CHECKPOINT_DIRECTORY={run_directory}")


if __name__ == "__main__":
    main()
