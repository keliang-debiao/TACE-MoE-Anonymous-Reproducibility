#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch
import yaml

from tace_moe.calibration import TemperatureScaler
from tace_moe.baselines import build_image_baseline
from tace_moe.engine import predict
from tace_moe.metrics import binary_metrics, reliability_rows, risk_coverage_curve
from tace_moe.model import TACEMoE
from tace_moe.training import make_loader


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--dataset-config", default="configs/datasets.yaml")
    parser.add_argument("--dataset-key", choices=["external_art", "external_stress"], required=True)
    parser.add_argument("--checkpoint-directory", default="outputs/external_checkpoint/seed_2026")
    parser.add_argument("--model", default="tace_moe")
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    data_config = yaml.safe_load(Path(args.dataset_config).read_text(encoding="utf-8"))
    inventory_key = "external_art_inventory" if args.dataset_key == "external_art" else "external_stress_inventory"
    inventory = pd.read_csv(config["paths"][inventory_key])
    dataset_root = Path(data_config["datasets"][args.dataset_key]["root"])
    loader = make_loader(
        inventory,
        dataset_root,
        config["preprocessing"],
        False,
        int(config["training"]["batch_size"]),
        int(config["training"]["num_workers"]),
        int(config["study"]["split_seed"]),
    )
    checkpoint_directory = Path(args.checkpoint_directory)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(checkpoint_directory / "best_checkpoint.pt", map_location=device, weights_only=False)
    model = TACEMoE(config).to(device) if args.model == "tace_moe" else build_image_baseline(args.model, config).to(device)
    model.load_state_dict(checkpoint["model_state"])
    temperature = TemperatureScaler.from_dict(
        json.loads((checkpoint_directory / "temperature.json").read_text(encoding="utf-8"))
    )
    frame = predict(model, loader, device)
    frame["probability_uncalibrated"] = frame["probability"]
    frame["probability"] = temperature.predict_proba(frame["logit"].to_numpy())
    output_directory = Path(config["paths"]["output_root"]) / "external" / args.dataset_key / args.model
    output_directory.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_directory / "predictions.csv", index=False)
    metrics = binary_metrics(frame["label"].to_numpy(), frame["probability"].to_numpy())
    (output_directory / "metrics.json").write_text(
        json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    pd.DataFrame(reliability_rows(frame["label"].to_numpy(), frame["probability"].to_numpy())).to_csv(
        output_directory / "reliability_bins.csv", index=False
    )
    coverage, risk, aurc = risk_coverage_curve(
        frame["label"].to_numpy(), frame["probability"].to_numpy(), frame["confidence"].to_numpy()
    )
    pd.DataFrame({"coverage": coverage, "risk": risk}).to_csv(
        output_directory / "risk_coverage.csv", index=False
    )
    print(json.dumps({**metrics, "aurc": aurc}, sort_keys=True))


if __name__ == "__main__":
    main()
