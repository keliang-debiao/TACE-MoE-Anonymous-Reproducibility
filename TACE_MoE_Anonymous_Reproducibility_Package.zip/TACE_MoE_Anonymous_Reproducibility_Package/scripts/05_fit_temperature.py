#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from tace_moe.calibration import TemperatureScaler
from tace_moe.metrics import binary_metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-directory", required=True)
    parser.add_argument("--maximum-iterations", type=int, default=50)
    args = parser.parse_args()
    run_directory = Path(args.run_directory)
    calibration = pd.read_csv(run_directory / "calibration_uncalibrated.csv")
    scaler = TemperatureScaler().fit(
        calibration["logit"].to_numpy(), calibration["label"].to_numpy(), args.maximum_iterations
    )
    (run_directory / "temperature.json").write_text(
        json.dumps(scaler.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    for path in sorted(run_directory.glob("*_uncalibrated.csv")):
        frame = pd.read_csv(path)
        frame["probability_uncalibrated"] = frame["probability"]
        frame["probability"] = scaler.predict_proba(frame["logit"].to_numpy())
        output = path.with_name(path.name.replace("_uncalibrated", "_calibrated"))
        frame.to_csv(output, index=False)
        metrics = binary_metrics(frame["label"].to_numpy(), frame["probability"].to_numpy())
        output.with_suffix(".metrics.json").write_text(
            json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
    print(f"TEMPERATURE={scaler.temperature:.8f}")


if __name__ == "__main__":
    main()
