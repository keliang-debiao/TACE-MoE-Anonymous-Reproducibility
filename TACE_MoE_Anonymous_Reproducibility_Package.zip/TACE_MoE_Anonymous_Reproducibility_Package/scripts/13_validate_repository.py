#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from tace_moe.bootstrap import paired_cluster_bootstrap
from tace_moe.calibration import TemperatureScaler
from tace_moe.config import load_config
from tace_moe.losses import composite_loss
from tace_moe.metrics import binary_metrics, risk_coverage_curve
from tace_moe.model import TACEMoE
from tace_moe.robustness import apply_condition
from tace_moe.seed import seed_everything
from tace_moe.splits import build_nested_split_manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    seed_everything(2026)
    config = load_config(root / "configs" / "ci_validation.yaml")
    model = TACEMoE(config)
    pixels = torch.rand(12, 3, 64, 64)
    labels = torch.tensor([0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1], dtype=torch.float32)
    output = model(pixels)
    assert output["logits"].shape == (12,)
    assert output["representations"].shape == (12, 3, 32)
    assert output["routing_weights"].shape == (12, 3)
    assert torch.allclose(output["routing_weights"].sum(dim=1), torch.ones(12), atol=1e-6)
    losses = composite_loss(output, labels, config["loss"])
    losses["total"].backward()
    assert torch.isfinite(losses["total"])

    logits = np.linspace(-3.0, 3.0, 40)
    calibration_labels = (logits + np.sin(np.arange(40)) * 0.6 > 0).astype(int)
    scaler = TemperatureScaler().fit(logits, calibration_labels, 20)
    probabilities = scaler.predict_proba(logits)
    metrics = binary_metrics(calibration_labels, probabilities)
    confidence = np.abs(probabilities - 0.5) * 2.0
    coverage, risk, aurc = risk_coverage_curve(calibration_labels, probabilities, confidence)
    assert len(coverage) == len(risk) == 40 and np.isfinite(aurc)

    inventory = pd.DataFrame(
        {
            "sample_id": [f"S{index:03d}" for index in range(60)],
            "label": [group % 2 for group in range(30) for _ in range(2)],
            "group_id": [f"G{group:03d}" for group in range(30) for _ in range(2)],
        }
    )
    manifest = build_nested_split_manifest(inventory, 5, 2026)
    assert len(manifest) == 300
    assert manifest.groupby(["outer_fold", "group_id"])["role"].nunique().max() == 1

    perturbed = apply_condition(
        pixels[:2],
        "noise",
        {"gaussian_noise_standard_deviation": 0.03},
        2026,
    )
    assert perturbed.shape == pixels[:2].shape and perturbed.min() >= 0 and perturbed.max() <= 1

    bootstrap = paired_cluster_bootstrap(
        calibration_labels,
        probabilities,
        np.clip(probabilities * 0.96 + 0.02, 0, 1),
        np.asarray([f"B{index // 2:02d}" for index in range(40)]),
        "f1",
        100,
        2026,
    )
    report = {
        "status": "PASS",
        "python": platform.python_version(),
        "torch": torch.__version__,
        "trainable_parameters_validation_model": model.trainable_parameter_count,
        "forward_shape": list(output["representations"].shape),
        "loss": float(losses["total"].detach()),
        "temperature": scaler.temperature,
        "metrics": metrics,
        "aurc": aurc,
        "split_rows": len(manifest),
        "bootstrap": bootstrap,
    }
    report_path = root / "artifacts" / "logs" / "validation_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))
    print("VALIDATION_STATUS=PASS")


if __name__ == "__main__":
    main()
