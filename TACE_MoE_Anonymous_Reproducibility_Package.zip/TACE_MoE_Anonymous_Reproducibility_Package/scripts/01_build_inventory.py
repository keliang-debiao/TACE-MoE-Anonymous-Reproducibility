#!/usr/bin/env python
from __future__ import annotations

import argparse
from io import BytesIO
import re
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from PIL import Image, ImageOps

from tace_moe.audit import decoded_sha256, perceptual_hash64
from tace_moe.data import discover_images, infer_label, stable_sample_id


_JPEG_TABLES: dict[int, np.ndarray] | None = None


def jpeg_reference_tables() -> dict[int, np.ndarray]:
    global _JPEG_TABLES
    if _JPEG_TABLES is None:
        image = Image.new("RGB", (16, 16), color=(128, 128, 128))
        values: dict[int, np.ndarray] = {}
        for quality in range(1, 101):
            stream = BytesIO()
            image.save(stream, format="JPEG", quality=quality, subsampling=2)
            stream.seek(0)
            with Image.open(stream) as decoded:
                values[quality] = np.asarray(decoded.quantization[0], dtype=float)
        _JPEG_TABLES = values
    return _JPEG_TABLES


def jpeg_descriptors(source: Image.Image) -> tuple[float, float]:
    if (source.format or "").upper() != "JPEG" or not getattr(source, "quantization", None):
        return float("nan"), float("nan")
    table = np.asarray(source.quantization[0], dtype=float)
    references = jpeg_reference_tables()
    quality = min(references, key=lambda value: float(np.mean((references[value] - table) ** 2)))
    return float(quality), float(table.mean())


def pair_identifier(path: Path) -> str:
    stem = path.stem.lower()
    stem = re.sub(r"(^|[_-])(ai|fake|generated|human|real|authentic)([_-]|$)", "_", stem)
    stem = re.sub(r"[_-]+", "_", stem).strip("_")
    return stem


def build_inventory(dataset_name: str, root: Path, aliases: dict[str, list[str]]) -> pd.DataFrame:
    rows = []
    for path in discover_images(root):
        relative = path.relative_to(root).as_posix()
        with Image.open(path) as source:
            transposed = ImageOps.exif_transpose(source)
            width, height = transposed.size
            codec = source.format or path.suffix.lstrip(".").upper()
            exif_available = int(bool(source.getexif()))
            jpeg_quality_estimate, jpeg_quantization_mean = jpeg_descriptors(source)
        rows.append(
            {
                "sample_id": stable_sample_id(dataset_name, relative),
                "dataset": dataset_name,
                "relative_path": relative,
                "label": infer_label(path.relative_to(root), aliases),
                "pair_id": pair_identifier(path),
                "source_id": path.parent.name,
                "sha256": decoded_sha256(path),
                "phash64": str(int(perceptual_hash64(path))),
                "width": width,
                "height": height,
                "codec": codec,
                "byte_size": path.stat().st_size,
                "jpeg_quality_estimate": jpeg_quality_estimate,
                "jpeg_quantization_mean": jpeg_quantization_mean,
                "exif_available": exif_available,
            }
        )
    return pd.DataFrame(rows).sort_values("sample_id").reset_index(drop=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--dataset-config", default="configs/datasets.yaml")
    args = parser.parse_args()
    main_config = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    data_config = yaml.safe_load(Path(args.dataset_config).read_text(encoding="utf-8"))
    mapping = {
        "development": "development_inventory",
        "external_art": "external_art_inventory",
        "external_stress": "external_stress_inventory",
    }
    for key, output_key in mapping.items():
        dataset = data_config["datasets"][key]
        frame = build_inventory(dataset["name"], Path(dataset["root"]), data_config["class_aliases"])
        expected = int(dataset["expected_images"])
        if len(frame) != expected:
            raise AssertionError(f"{key}: expected {expected} images, found {len(frame)}")
        output = Path(main_config["paths"][output_key])
        output.parent.mkdir(parents=True, exist_ok=True)
        frame.to_csv(output, index=False)
        print(f"{key.upper()}_IMAGES={len(frame)}")


if __name__ == "__main__":
    main()
