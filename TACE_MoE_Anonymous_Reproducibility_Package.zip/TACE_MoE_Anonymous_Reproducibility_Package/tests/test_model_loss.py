import torch

from tace_moe.config import load_config
from tace_moe.losses import composite_loss
from tace_moe.model import TACEMoE


def test_forward_router_and_backward():
    config = load_config("configs/ci_validation.yaml")
    model = TACEMoE(config)
    pixels = torch.rand(8, 3, 64, 64)
    labels = torch.tensor([0, 0, 1, 1, 0, 1, 0, 1], dtype=torch.float32)
    output = model(pixels)
    assert output["representations"].shape == (8, 3, 32)
    assert output["expert_probabilities"].shape == (8, 3)
    assert torch.allclose(output["routing_weights"].sum(dim=1), torch.ones(8), atol=1e-6)
    losses = composite_loss(output, labels, config["loss"])
    losses["total"].backward()
    assert float(losses["total"].detach()) > 0
    assert any(parameter.grad is not None for parameter in model.parameters())
