import numpy as np

from tace_moe.calibration import TemperatureScaler
from tace_moe.metrics import binary_metrics, risk_coverage_curve


def test_temperature_is_positive_and_metrics_are_bounded():
    logits = np.linspace(-4, 4, 100)
    labels = (logits + 0.4 * np.sin(np.arange(100)) > 0).astype(int)
    scaler = TemperatureScaler().fit(logits, labels, maximum_iterations=20)
    probabilities = scaler.predict_proba(logits)
    metrics = binary_metrics(labels, probabilities)
    assert scaler.temperature > 0
    for name in ["accuracy", "precision", "recall", "f1", "auroc", "auprc", "brier", "ece"]:
        assert 0 <= metrics[name] <= 1
    confidence = np.abs(probabilities - 0.5) * 2
    coverage, risk, aurc = risk_coverage_curve(labels, probabilities, confidence)
    assert len(coverage) == len(risk) == len(labels)
    assert 0 <= aurc <= 1
