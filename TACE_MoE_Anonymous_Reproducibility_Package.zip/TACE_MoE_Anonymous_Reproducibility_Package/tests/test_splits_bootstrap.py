import numpy as np
import pandas as pd

from tace_moe.bootstrap import holm_adjust, paired_cluster_bootstrap
from tace_moe.splits import build_nested_split_manifest


def test_group_isolation_and_outer_test_once():
    inventory = pd.DataFrame(
        {
            "sample_id": [f"S{index:03d}" for index in range(80)],
            "label": [group % 2 for group in range(40) for _ in range(2)],
            "group_id": [f"G{group:03d}" for group in range(40) for _ in range(2)],
        }
    )
    manifest = build_nested_split_manifest(inventory, outer_folds=5, seed=2026)
    assert manifest.groupby(["outer_fold", "group_id"])["role"].nunique().max() == 1
    assert (manifest[manifest["role"] == "test"].groupby("sample_id").size() == 1).all()


def test_cluster_bootstrap_and_holm():
    labels = np.array([0, 0, 1, 1] * 10)
    left = np.where(labels == 1, 0.85, 0.15)
    right = np.where(labels == 1, 0.75, 0.25)
    groups = np.array([f"G{index // 2:02d}" for index in range(40)])
    result = paired_cluster_bootstrap(labels, left, right, groups, "ece", 100, 2026)
    assert result["valid_replicates"] == 100
    adjusted = holm_adjust([0.01, 0.04, 0.2])
    assert len(adjusted) == 3
    assert all(0 <= value <= 1 for value in adjusted)
