import torch

from tace_moe.robustness import apply_condition


def test_all_tensor_conditions_preserve_shape_and_range():
    images = torch.rand(2, 3, 32, 32)
    config = {
        "jpeg_quality": 70,
        "gaussian_noise_standard_deviation": 0.03,
        "patch_occlusion_fraction": 0.10,
        "down_resize": 16,
        "center_crop_fraction": 0.80,
        "gaussian_blur_sigma": 1.5,
        "social_media_long_edge": 64,
        "social_media_jpeg_quality": 85,
    }
    names = ["clean", "jpeg70", "noise", "occlusion", "down_up", "center_crop", "blur", "screenshot", "social_media"]
    for name in names:
        output = apply_condition(images, name, config, 2026)
        assert output.shape == images.shape
        assert float(output.min()) >= 0
        assert float(output.max()) <= 1
