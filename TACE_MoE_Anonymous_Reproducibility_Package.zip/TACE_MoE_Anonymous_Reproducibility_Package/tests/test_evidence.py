import torch

from tace_moe.evidence import haar_high_frequency, nearest_patch_residual, pixel_statistics


def test_evidence_shapes_and_finiteness():
    values = torch.linspace(0, 1, 2 * 3 * 32 * 32).reshape(2, 3, 32, 32)
    residual = nearest_patch_residual(values, radius=2)
    frequency = haar_high_frequency(values)
    statistics = pixel_statistics(values)
    assert residual.shape == values.shape
    assert frequency.shape == (2, 9, 16, 16)
    assert statistics.shape == (2, 6)
    assert torch.isfinite(residual).all()
    assert torch.isfinite(frequency).all()


def test_constant_image_has_zero_residual_and_high_frequency():
    values = torch.full((1, 3, 16, 16), 0.4)
    assert torch.allclose(nearest_patch_residual(values), torch.zeros_like(values))
    assert torch.allclose(haar_high_frequency(values), torch.zeros(1, 9, 8, 8), atol=1e-6)
