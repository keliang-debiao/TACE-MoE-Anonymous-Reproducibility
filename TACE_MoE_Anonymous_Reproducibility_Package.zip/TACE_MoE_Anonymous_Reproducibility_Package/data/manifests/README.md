# Manifest directory

This directory stores audit-only records and split-control files. Image content is not stored here.

Required generated files for a manuscript-scale run:

- `kaggle_records/`: dataset metadata JSON, file list, capture command, and access index.
- `development_inventory.csv`: image identifiers, labels, pair identifiers, hashes, dimensions, codecs, byte sizes, JPEG quantization descriptors, and EXIF availability.
- `external_art_inventory.csv` and `external_stress_inventory.csv`: external dataset inventories with the same audit fields.
- `development_dinov2.npy` and `development_dinov2.csv`: normalized frozen DINOv2 audit embeddings and aligned identifiers.
- `development_group_edges.csv`: every explicit-pair, exact-hash, pHash, or embedding edge.
- `development_groups.csv`: connected-component group assignment.
- `development_folds.csv`: one row per image per outer fold with `fit`, `selection`, `calibration`, or `test` role.
- `development_fold_overlap_audit.csv`: pairwise group overlap counts between roles; every value must be zero.

The exact Kaggle version metadata and per-file image checksums must be captured from the same local snapshots used for training. They are deliberately not inferred from a later public snapshot.
