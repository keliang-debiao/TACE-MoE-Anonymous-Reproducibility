# Manuscript targets

These files are a machine-readable transcription of values reported in the revised manuscript. They are comparison targets only. Training, calibration, evaluation, and statistical programs do not read this directory.

Fresh run outputs belong under `outputs/`. A result is reproduced only when it is generated from the frozen dataset snapshots and passes the output contract; matching a target by manual entry is not reproduction.
