from __future__ import annotations

from collections.abc import Callable

import numpy as np

from .metrics import binary_metrics


def _metric_value(name: str, labels: np.ndarray, probabilities: np.ndarray) -> float:
    return float(binary_metrics(labels, probabilities)[name])


def paired_cluster_bootstrap(
    labels: np.ndarray,
    probabilities_a: np.ndarray,
    probabilities_b: np.ndarray,
    groups: np.ndarray,
    metric: str,
    replicates: int = 10000,
    seed: int = 2026,
) -> dict[str, float]:
    labels = np.asarray(labels)
    probabilities_a = np.asarray(probabilities_a)
    probabilities_b = np.asarray(probabilities_b)
    groups = np.asarray(groups).astype(str)
    if not (labels.size == probabilities_a.size == probabilities_b.size == groups.size):
        raise ValueError("Bootstrap inputs must be aligned")
    unique_groups = np.unique(groups)
    indices_by_group = {group: np.flatnonzero(groups == group) for group in unique_groups}
    rng = np.random.default_rng(seed)
    differences: list[float] = []
    for _ in range(replicates):
        sampled_groups = rng.choice(unique_groups, size=unique_groups.size, replace=True)
        sampled_indices = np.concatenate([indices_by_group[group] for group in sampled_groups])
        y = labels[sampled_indices]
        if metric in {"auroc", "auprc"} and np.unique(y).size < 2:
            continue
        value_a = _metric_value(metric, y, probabilities_a[sampled_indices])
        value_b = _metric_value(metric, y, probabilities_b[sampled_indices])
        differences.append(value_a - value_b)
    if len(differences) < max(20, replicates // 2):
        raise RuntimeError("Too few valid bootstrap replicates")
    distribution = np.asarray(differences)
    estimate = _metric_value(metric, labels, probabilities_a) - _metric_value(metric, labels, probabilities_b)
    lower, upper = np.quantile(distribution, [0.025, 0.975])
    p_value = 2.0 * min((distribution <= 0).mean(), (distribution >= 0).mean())
    return {
        "estimate": float(estimate),
        "ci_lower": float(lower),
        "ci_upper": float(upper),
        "p_value": float(min(1.0, p_value)),
        "valid_replicates": int(distribution.size),
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    count = len(values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (count - rank) * values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted.tolist()
