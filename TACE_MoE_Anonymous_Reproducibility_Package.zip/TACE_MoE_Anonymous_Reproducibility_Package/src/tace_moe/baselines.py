from __future__ import annotations

import math
from typing import Any

import torch
from torch import nn

from .evidence import nearest_patch_residual
from .model import FourStageEncoder, RGBEncoder, bernoulli_entropy


class RGBNPRBaseline(nn.Module):
    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__()
        model_config = config["model"]
        channels = [int(value) for value in model_config["evidence_channels"]]
        dimension = int(model_config["representation_dim"])
        self.radius = int(config["evidence"]["npr_radius"])
        self.rgb_encoder = RGBEncoder(
            str(model_config["rgb_backbone"]),
            bool(model_config.get("rgb_pretrained", True)),
            dimension,
            channels,
        )
        self.npr_encoder = FourStageEncoder(3, channels, dimension)
        self.head = nn.Linear(dimension * 2, 1)
        self.register_buffer("rgb_mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("rgb_std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, pixels: torch.Tensor) -> dict[str, torch.Tensor]:
        rgb_representation = self.rgb_encoder((pixels - self.rgb_mean) / self.rgb_std)
        npr_representation = self.npr_encoder(nearest_patch_residual(pixels, self.radius))
        logits = self.head(torch.cat([rgb_representation, npr_representation], dim=1)).squeeze(1)
        probability = logits.sigmoid()
        confidence = 1.0 - bernoulli_entropy(probability) / math.log(2.0)
        return {"logits": logits, "probability": probability, "confidence": confidence}


class TimmBinaryClassifier(nn.Module):
    def __init__(self, model_name: str, pretrained: bool = True, frozen: bool = False) -> None:
        super().__init__()
        try:
            import timm
        except ImportError as exc:
            raise RuntimeError("timm is required for image baselines") from exc
        self.backbone = timm.create_model(model_name, pretrained=pretrained, num_classes=0, global_pool="avg")
        self.head = nn.Linear(int(self.backbone.num_features), 1)
        if frozen:
            for parameter in self.backbone.parameters():
                parameter.requires_grad = False
        self.register_buffer("rgb_mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("rgb_std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, pixels: torch.Tensor) -> dict[str, torch.Tensor]:
        representation = self.backbone((pixels - self.rgb_mean) / self.rgb_std)
        logits = self.head(representation).squeeze(1)
        probability = logits.sigmoid()
        confidence = 1.0 - bernoulli_entropy(probability) / math.log(2.0)
        return {"logits": logits, "probability": probability, "confidence": confidence}


def build_image_baseline(name: str, config: dict[str, Any]) -> nn.Module:
    if name == "rgb_npr":
        return RGBNPRBaseline(config)
    mapping = {
        "resnet50": "resnet50",
        "convnext_tiny": "convnext_tiny",
        "vit_base_patch16_224": "vit_base_patch16_224",
        "dinov2_b14_linear": "vit_base_patch14_dinov2.lvd142m",
        "siglip2_b16_224_linear": "vit_base_patch16_siglip2_224",
    }
    if name not in mapping:
        raise KeyError(f"Unknown image baseline: {name}")
    return TimmBinaryClassifier(mapping[name], pretrained=True, frozen=name.endswith("_linear"))
