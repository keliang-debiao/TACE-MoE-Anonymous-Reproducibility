from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
import torch
import yaml
from torch.utils.data import DataLoader

from .data import ImageManifestDataset
from .engine import EarlyStopping, atomic_torch_save, evaluate_predictions, predict, train_one_epoch
from .evidence import haar_high_frequency
from .model import TACEMoE
from .seed import seed_everything, seed_worker


def make_loader(
    frame: pd.DataFrame,
    data_root: str | Path,
    preprocessing: dict[str, Any],
    training: bool,
    batch_size: int,
    workers: int,
    seed: int,
) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(
        ImageManifestDataset(frame, data_root, preprocessing, training),
        batch_size=batch_size,
        shuffle=training,
        num_workers=workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=workers > 0,
        worker_init_fn=seed_worker,
        generator=generator,
        drop_last=training,
    )


@torch.inference_mode()
def estimate_frequency_statistics(loader: DataLoader, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    total = torch.zeros(9, dtype=torch.float64, device=device)
    total_squares = torch.zeros(9, dtype=torch.float64, device=device)
    count = 0
    for batch in loader:
        frequency = haar_high_frequency(batch["pixels"].to(device)).double()
        total += frequency.sum(dim=(0, 2, 3))
        total_squares += frequency.square().sum(dim=(0, 2, 3))
        count += frequency.shape[0] * frequency.shape[2] * frequency.shape[3]
    mean = total / count
    variance = total_squares / count - mean.square()
    return mean.float(), variance.clamp_min(1e-12).sqrt().float()


def run_training(
    config: dict[str, Any],
    inventory: pd.DataFrame,
    split: pd.DataFrame,
    data_root: str | Path,
    run_directory: str | Path,
    seed: int,
) -> None:
    seed_everything(seed)
    run_directory = Path(run_directory)
    run_directory.mkdir(parents=True, exist_ok=True)
    merged = split[["sample_id", "role"]].merge(inventory, on="sample_id", how="left", validate="one_to_one")
    if merged["relative_path"].isna().any():
        raise ValueError("Split manifest contains unknown sample identifiers")
    training_config = config["training"]
    batch_size = int(training_config["batch_size"])
    workers = int(training_config["num_workers"])
    loaders = {
        role: make_loader(
            merged[merged["role"] == role],
            data_root,
            config["preprocessing"],
            role == "fit",
            batch_size,
            workers,
            seed + index,
        )
        for index, role in enumerate(["fit", "selection", "calibration", "test"])
        if (merged["role"] == role).any()
    }
    statistics_loader = make_loader(
        merged[merged["role"] == "fit"],
        data_root,
        config["preprocessing"],
        False,
        batch_size,
        workers,
        seed + 99,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = TACEMoE(config).to(device)
    frequency_mean, frequency_std = estimate_frequency_statistics(statistics_loader, device)
    model.set_frequency_statistics(frequency_mean, frequency_std)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(training_config["maximum_learning_rate"]),
        weight_decay=float(training_config["weight_decay"]),
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=int(training_config["epochs"]))
    use_amp = bool(training_config.get("mixed_precision", True)) and device.type == "cuda"
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp) if use_amp else None
    stopper = EarlyStopping(int(training_config["early_stopping_patience"]))
    history: list[dict[str, Any]] = []
    checkpoint_path = run_directory / "best_checkpoint.pt"
    for epoch in range(1, int(training_config["epochs"]) + 1):
        train_losses = train_one_epoch(
            model,
            loaders["fit"],
            optimizer,
            config["loss"],
            device,
            scaler,
            float(training_config["gradient_clip_norm"]),
        )
        selection_predictions = predict(model, loaders["selection"], device)
        selection_metrics = evaluate_predictions(selection_predictions, bins=int(config["metrics"]["ece_bins"]))
        improved = stopper.update(selection_metrics["nll"])
        row = {
            "epoch": epoch,
            "learning_rate": optimizer.param_groups[0]["lr"],
            **{f"train_{key}": value for key, value in train_losses.items()},
            **{f"selection_{key}": value for key, value in selection_metrics.items()},
            "checkpoint_updated": improved,
        }
        history.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
        if improved:
            atomic_torch_save(
                {
                    "model_state": model.state_dict(),
                    "epoch": epoch,
                    "selection_nll": selection_metrics["nll"],
                    "seed": seed,
                    "config": config,
                },
                checkpoint_path,
            )
        scheduler.step()
        if stopper.should_stop:
            break
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state"])
    pd.DataFrame(history).to_csv(run_directory / "training_history.csv", index=False)
    for role in ("selection", "calibration", "test"):
        if role in loaders:
            predict(model, loaders[role], device).to_csv(
                run_directory / f"{role}_uncalibrated.csv", index=False
            )
    (run_directory / "resolved_config.yaml").write_text(
        yaml.safe_dump(config, sort_keys=True), encoding="utf-8"
    )
    (run_directory / "run_provenance.json").write_text(
        json.dumps(
            {
                "seed": seed,
                "device": str(device),
                "torch_version": torch.__version__,
                "cuda_version": torch.version.cuda,
                "trainable_parameters": model.trainable_parameter_count,
                "best_epoch": int(checkpoint["epoch"]),
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
