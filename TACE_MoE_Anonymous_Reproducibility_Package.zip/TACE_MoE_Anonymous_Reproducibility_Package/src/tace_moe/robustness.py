from __future__ import annotations

from io import BytesIO

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageFilter


def _tensor_to_pil(image: torch.Tensor) -> Image.Image:
    array = (image.detach().cpu().clamp(0, 1).permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)
    return Image.fromarray(array, mode="RGB")


def _pil_to_tensor(image: Image.Image, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    array = np.asarray(image.convert("RGB"), dtype=np.float32) / 255.0
    return torch.from_numpy(array.transpose(2, 0, 1).copy()).to(device=device, dtype=dtype)


def jpeg_batch(images: torch.Tensor, quality: int) -> torch.Tensor:
    output = []
    for image in images:
        stream = BytesIO()
        _tensor_to_pil(image).save(stream, format="JPEG", quality=quality, subsampling=2)
        stream.seek(0)
        with Image.open(stream) as decoded:
            output.append(_pil_to_tensor(decoded, images.device, images.dtype))
    return torch.stack(output)


def gaussian_noise(images: torch.Tensor, standard_deviation: float, seed: int) -> torch.Tensor:
    generator = torch.Generator(device=images.device).manual_seed(seed)
    noise = torch.randn(images.shape, generator=generator, device=images.device, dtype=images.dtype)
    return (images + standard_deviation * noise).clamp(0, 1)


def patch_occlusion(images: torch.Tensor, fraction: float, seed: int) -> torch.Tensor:
    output = images.clone()
    side = max(1, round((fraction * images.shape[-2] * images.shape[-1]) ** 0.5))
    rng = np.random.default_rng(seed)
    for index in range(images.shape[0]):
        top = int(rng.integers(0, images.shape[-2] - side + 1))
        left = int(rng.integers(0, images.shape[-1] - side + 1))
        output[index, :, top : top + side, left : left + side] = 0.5
    return output


def down_up_resize(images: torch.Tensor, size: int) -> torch.Tensor:
    down = F.interpolate(images, size=(size, size), mode="bicubic", align_corners=False, antialias=True)
    return F.interpolate(down, size=images.shape[-2:], mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)


def center_crop_resize(images: torch.Tensor, fraction: float) -> torch.Tensor:
    height, width = images.shape[-2:]
    crop_height, crop_width = round(height * fraction), round(width * fraction)
    top, left = (height - crop_height) // 2, (width - crop_width) // 2
    crop = images[:, :, top : top + crop_height, left : left + crop_width]
    return F.interpolate(crop, size=(height, width), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)


def gaussian_blur(images: torch.Tensor, sigma: float) -> torch.Tensor:
    output = []
    for image in images:
        pil = _tensor_to_pil(image).filter(ImageFilter.GaussianBlur(radius=sigma))
        output.append(_pil_to_tensor(pil, images.device, images.dtype))
    return torch.stack(output)


def screenshot_recapture(images: torch.Tensor) -> torch.Tensor:
    height, width = images.shape[-2:]
    enlarged = F.interpolate(images, scale_factor=1.25, mode="bilinear", align_corners=False, antialias=True)
    quantized = (enlarged.clamp(0, 1) * 255.0).round() / 255.0
    return F.interpolate(quantized, size=(height, width), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)


def social_media_proxy(images: torch.Tensor, long_edge: int = 1080, quality: int = 85) -> torch.Tensor:
    height, width = images.shape[-2:]
    if height >= width:
        target = (long_edge, round(long_edge * width / height))
    else:
        target = (round(long_edge * height / width), long_edge)
    enlarged = F.interpolate(images, size=target, mode="bicubic", align_corners=False, antialias=True)
    compressed = jpeg_batch(enlarged, quality)
    return F.interpolate(compressed, size=(height, width), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)


def apply_condition(images: torch.Tensor, name: str, config: dict[str, float | int], seed: int) -> torch.Tensor:
    if name == "clean":
        return images
    if name == "jpeg70":
        return jpeg_batch(images, int(config["jpeg_quality"]))
    if name == "noise":
        return gaussian_noise(images, float(config["gaussian_noise_standard_deviation"]), seed)
    if name == "occlusion":
        return patch_occlusion(images, float(config["patch_occlusion_fraction"]), seed)
    if name == "down_up":
        return down_up_resize(images, int(config["down_resize"]))
    if name == "center_crop":
        return center_crop_resize(images, float(config["center_crop_fraction"]))
    if name == "blur":
        return gaussian_blur(images, float(config["gaussian_blur_sigma"]))
    if name == "screenshot":
        return screenshot_recapture(images)
    if name == "social_media":
        return social_media_proxy(
            images,
            int(config["social_media_long_edge"]),
            int(config["social_media_jpeg_quality"]),
        )
    raise KeyError(f"Unknown robustness condition: {name}")
