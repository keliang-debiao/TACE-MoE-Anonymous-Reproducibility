"""TACE-MoE reproduction package."""

__version__ = "1.0.0"

from .model import TACEMoE

__all__ = ["TACEMoE", "__version__"]
