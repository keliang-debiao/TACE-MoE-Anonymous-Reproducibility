from __future__ import annotations

from itertools import permutations
from typing import Any

import torch
import torch.nn.functional as F


def cross_evidence_contrastive_loss(
    representations: torch.Tensor,
    labels: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    if representations.ndim != 3 or representations.shape[1] != 3:
        raise ValueError("representations must have shape [batch, 3, dimension]")
    normalized = F.normalize(representations, dim=2)
    batch_size = labels.numel()
    if batch_size < 3:
        return representations.sum() * 0.0
    eye = torch.eye(batch_size, dtype=torch.bool, device=labels.device)
    same_class = labels[:, None].eq(labels[None, :]) & ~eye
    all_other = ~eye
    losses: list[torch.Tensor] = []
    negative_large = torch.finfo(representations.dtype).min
    for left, right in permutations(range(3), 2):
        similarity = normalized[:, left] @ normalized[:, right].T / temperature
        valid = same_class.any(dim=1)
        if not valid.any():
            continue
        numerator = torch.logsumexp(similarity.masked_fill(~same_class, negative_large), dim=1)
        denominator = torch.logsumexp(similarity.masked_fill(~all_other, negative_large), dim=1)
        losses.append(-(numerator[valid] - denominator[valid]).mean())
    return torch.stack(losses).mean() if losses else representations.sum() * 0.0


def class_conditional_mean_discrepancy(
    representations: torch.Tensor,
    labels: torch.Tensor,
) -> torch.Tensor:
    terms: list[torch.Tensor] = []
    for class_value in (0, 1):
        mask = labels == class_value
        if mask.sum() == 0:
            continue
        means = representations[mask].mean(dim=0)
        for left in range(3):
            for right in range(left + 1, 3):
                terms.append((means[left] - means[right]).square().sum())
    return torch.stack(terms).mean() if terms else representations.sum() * 0.0


def composite_loss(
    output: dict[str, torch.Tensor],
    labels: torch.Tensor,
    config: dict[str, Any],
) -> dict[str, torch.Tensor]:
    labels = labels.float()
    fused_bce = F.binary_cross_entropy_with_logits(output["logits"], labels)
    expanded_labels = labels[:, None].expand_as(output["expert_logits"])
    expert_bce = F.binary_cross_entropy_with_logits(output["expert_logits"], expanded_labels)
    contrastive = cross_evidence_contrastive_loss(
        output["representations"], labels.long(), float(config["contrastive_temperature"])
    )
    discrepancy = class_conditional_mean_discrepancy(output["representations"], labels.long())
    brier = (output["probability"] - labels).square().mean()
    total = (
        fused_bce
        + float(config["expert_weight"]) * expert_bce
        + float(config["contrastive_weight"]) * contrastive
        + float(config["discrepancy_weight"]) * discrepancy
        + float(config["brier_weight"]) * brier
    )
    return {
        "total": total,
        "fused_bce": fused_bce,
        "expert_bce": expert_bce,
        "contrastive": contrastive,
        "discrepancy": discrepancy,
        "brier": brier,
    }
