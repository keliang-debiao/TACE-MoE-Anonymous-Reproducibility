from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .bootstrap import paired_cluster_bootstrap
from .calibration import TemperatureScaler
from .config import load_config
from .metrics import binary_metrics, reliability_rows, risk_coverage_curve
from .model import TACEMoE
from .splits import assert_split_isolation, build_nested_split_manifest, split_summary


def command_model_info(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    model = TACEMoE(config)
    print(json.dumps({"trainable_parameters": model.trainable_parameter_count}, sort_keys=True))


def command_build_splits(args: argparse.Namespace) -> None:
    inventory = pd.read_csv(args.inventory)
    manifest = build_nested_split_manifest(inventory, args.outer_folds, args.seed)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    manifest.to_csv(args.output, index=False)
    print(split_summary(manifest).to_string(index=False))


def command_check_splits(args: argparse.Namespace) -> None:
    manifest = pd.read_csv(args.manifest)
    assert_split_isolation(manifest)
    print("SPLIT_ISOLATION=PASS")


def command_calibrate(args: argparse.Namespace) -> None:
    frame = pd.read_csv(args.predictions)
    scaler = TemperatureScaler().fit(
        frame[args.logit_column].to_numpy(), frame[args.label_column].to_numpy(), args.maximum_iterations
    )
    value = scaler.to_dict()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(value, sort_keys=True))


def command_metrics(args: argparse.Namespace) -> None:
    frame = pd.read_csv(args.predictions)
    metrics = binary_metrics(
        frame[args.label_column].to_numpy(),
        frame[args.probability_column].to_numpy(),
        threshold=args.threshold,
        bins=args.bins,
    )
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(metrics, sort_keys=True))


def command_reliability(args: argparse.Namespace) -> None:
    frame = pd.read_csv(args.predictions)
    rows = reliability_rows(
        frame[args.label_column].to_numpy(), frame[args.probability_column].to_numpy(), args.bins
    )
    pd.DataFrame(rows).to_csv(args.output, index=False)


def command_risk_coverage(args: argparse.Namespace) -> None:
    frame = pd.read_csv(args.predictions)
    coverage, risk, aurc = risk_coverage_curve(
        frame[args.label_column].to_numpy(),
        frame[args.probability_column].to_numpy(),
        frame[args.confidence_column].to_numpy(),
    )
    pd.DataFrame({"coverage": coverage, "risk": risk}).to_csv(args.output, index=False)
    print(json.dumps({"aurc": aurc}))


def command_bootstrap(args: argparse.Namespace) -> None:
    left = pd.read_csv(args.left).sort_values("sample_id").reset_index(drop=True)
    right = pd.read_csv(args.right).sort_values("sample_id").reset_index(drop=True)
    if not left["sample_id"].equals(right["sample_id"]):
        raise ValueError("Prediction files are not sample-aligned")
    result = paired_cluster_bootstrap(
        left[args.label_column].to_numpy(),
        left[args.probability_column].to_numpy(),
        right[args.probability_column].to_numpy(),
        left[args.group_column].to_numpy(),
        args.metric,
        args.replicates,
        args.seed,
    )
    Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, sort_keys=True))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="tace-moe")
    commands = parser.add_subparsers(dest="command", required=True)

    model_info = commands.add_parser("model-info")
    model_info.add_argument("--config", required=True)
    model_info.set_defaults(function=command_model_info)

    build_splits = commands.add_parser("build-splits")
    build_splits.add_argument("--inventory", required=True)
    build_splits.add_argument("--output", required=True)
    build_splits.add_argument("--outer-folds", type=int, default=5)
    build_splits.add_argument("--seed", type=int, default=2026)
    build_splits.set_defaults(function=command_build_splits)

    check_splits = commands.add_parser("check-splits")
    check_splits.add_argument("--manifest", required=True)
    check_splits.set_defaults(function=command_check_splits)

    calibrate = commands.add_parser("calibrate")
    calibrate.add_argument("--predictions", required=True)
    calibrate.add_argument("--output", required=True)
    calibrate.add_argument("--logit-column", default="logit")
    calibrate.add_argument("--label-column", default="label")
    calibrate.add_argument("--maximum-iterations", type=int, default=50)
    calibrate.set_defaults(function=command_calibrate)

    metrics = commands.add_parser("metrics")
    metrics.add_argument("--predictions", required=True)
    metrics.add_argument("--output", required=True)
    metrics.add_argument("--probability-column", default="probability")
    metrics.add_argument("--label-column", default="label")
    metrics.add_argument("--threshold", type=float, default=0.5)
    metrics.add_argument("--bins", type=int, default=15)
    metrics.set_defaults(function=command_metrics)

    reliability = commands.add_parser("reliability")
    reliability.add_argument("--predictions", required=True)
    reliability.add_argument("--output", required=True)
    reliability.add_argument("--probability-column", default="probability")
    reliability.add_argument("--label-column", default="label")
    reliability.add_argument("--bins", type=int, default=15)
    reliability.set_defaults(function=command_reliability)

    risk = commands.add_parser("risk-coverage")
    risk.add_argument("--predictions", required=True)
    risk.add_argument("--output", required=True)
    risk.add_argument("--probability-column", default="probability")
    risk.add_argument("--confidence-column", default="confidence")
    risk.add_argument("--label-column", default="label")
    risk.set_defaults(function=command_risk_coverage)

    bootstrap = commands.add_parser("bootstrap")
    bootstrap.add_argument("--left", required=True)
    bootstrap.add_argument("--right", required=True)
    bootstrap.add_argument("--output", required=True)
    bootstrap.add_argument("--metric", choices=["accuracy", "f1", "auroc", "ece"], required=True)
    bootstrap.add_argument("--replicates", type=int, default=10000)
    bootstrap.add_argument("--seed", type=int, default=2026)
    bootstrap.add_argument("--probability-column", default="probability")
    bootstrap.add_argument("--label-column", default="label")
    bootstrap.add_argument("--group-column", default="group_id")
    bootstrap.set_defaults(function=command_bootstrap)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.function(args)


if __name__ == "__main__":
    main()
