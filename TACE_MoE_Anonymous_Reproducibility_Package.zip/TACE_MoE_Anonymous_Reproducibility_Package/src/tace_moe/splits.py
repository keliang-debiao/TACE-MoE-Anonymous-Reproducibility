from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit, StratifiedGroupKFold


@dataclass(frozen=True)
class PartitionScore:
    size_error: float
    prevalence_error: float

    @property
    def total(self) -> float:
        return self.size_error + self.prevalence_error


def _best_group_holdout(
    frame: pd.DataFrame,
    test_fraction: float,
    seed: int,
    candidates: int = 256,
) -> tuple[np.ndarray, np.ndarray]:
    labels = frame["label"].to_numpy()
    groups = frame["group_id"].astype(str).to_numpy()
    target_prevalence = labels.mean()
    best: tuple[float, np.ndarray, np.ndarray] | None = None
    for offset in range(candidates):
        splitter = GroupShuffleSplit(n_splits=1, test_size=test_fraction, random_state=seed + offset)
        train_indices, test_indices = next(splitter.split(frame, labels, groups))
        score = PartitionScore(
            size_error=abs(len(test_indices) / len(frame) - test_fraction),
            prevalence_error=abs(labels[test_indices].mean() - target_prevalence),
        ).total
        if best is None or score < best[0]:
            best = (score, train_indices, test_indices)
    if best is None:
        raise RuntimeError("Unable to create group holdout")
    return best[1], best[2]


def build_nested_split_manifest(
    inventory: pd.DataFrame,
    outer_folds: int = 5,
    seed: int = 2026,
) -> pd.DataFrame:
    required = {"sample_id", "label", "group_id"}
    missing = required.difference(inventory.columns)
    if missing:
        raise ValueError(f"Inventory missing columns: {sorted(missing)}")
    if inventory["sample_id"].duplicated().any():
        raise ValueError("sample_id must be unique")
    rows: list[pd.DataFrame] = []
    outer = StratifiedGroupKFold(n_splits=outer_folds, shuffle=True, random_state=seed)
    labels = inventory["label"].to_numpy()
    groups = inventory["group_id"].astype(str).to_numpy()
    for outer_index, (development_indices, test_indices) in enumerate(
        outer.split(inventory, labels, groups), start=1
    ):
        development = inventory.iloc[development_indices].reset_index(drop=True)
        fit_indices, held_indices = _best_group_holdout(development, 0.20, seed + outer_index * 1000)
        held = development.iloc[held_indices].reset_index(drop=True)
        selection_indices, calibration_indices = _best_group_holdout(
            held, 0.50, seed + outer_index * 1000 + 500
        )
        role_by_sample: dict[str, str] = {}
        for sample_id in development.iloc[fit_indices]["sample_id"]:
            role_by_sample[str(sample_id)] = "fit"
        for sample_id in held.iloc[selection_indices]["sample_id"]:
            role_by_sample[str(sample_id)] = "selection"
        for sample_id in held.iloc[calibration_indices]["sample_id"]:
            role_by_sample[str(sample_id)] = "calibration"
        for sample_id in inventory.iloc[test_indices]["sample_id"]:
            role_by_sample[str(sample_id)] = "test"
        fold = inventory[["sample_id", "label", "group_id"]].copy()
        fold.insert(0, "outer_fold", outer_index)
        fold["role"] = fold["sample_id"].astype(str).map(role_by_sample)
        if fold["role"].isna().any():
            raise RuntimeError("Unassigned samples detected")
        rows.append(fold)
    manifest = pd.concat(rows, ignore_index=True)
    assert_split_isolation(manifest)
    return manifest


def assert_split_isolation(manifest: pd.DataFrame) -> None:
    for outer_fold, fold in manifest.groupby("outer_fold"):
        group_roles = fold.groupby("group_id")["role"].nunique()
        if int(group_roles.max()) != 1:
            leaking = group_roles[group_roles > 1].index.astype(str).tolist()[:10]
            raise AssertionError(f"Group leakage in outer fold {outer_fold}: {leaking}")
        if fold["sample_id"].duplicated().any():
            raise AssertionError(f"Duplicate sample rows in outer fold {outer_fold}")
        if set(fold["role"]) != {"fit", "selection", "calibration", "test"}:
            raise AssertionError(f"Missing partition role in outer fold {outer_fold}")


def split_summary(manifest: pd.DataFrame) -> pd.DataFrame:
    summary = (
        manifest.groupby(["outer_fold", "role"], as_index=False)
        .agg(images=("sample_id", "size"), groups=("group_id", "nunique"), prevalence=("label", "mean"))
        .sort_values(["outer_fold", "role"])
    )
    return summary
