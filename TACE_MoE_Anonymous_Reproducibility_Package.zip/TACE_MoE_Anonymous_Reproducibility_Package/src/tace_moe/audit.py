from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageOps
from scipy.fft import dctn


def decoded_sha256(path: str | Path) -> str:
    with Image.open(path) as source:
        image = ImageOps.exif_transpose(source).convert("RGB")
        array = np.asarray(image, dtype=np.uint8)
    digest = hashlib.sha256()
    digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
    digest.update(array.tobytes(order="C"))
    return digest.hexdigest()


def perceptual_hash64(path: str | Path) -> np.uint64:
    with Image.open(path) as source:
        image = ImageOps.exif_transpose(source).convert("L").resize((32, 32), Image.Resampling.LANCZOS)
        array = np.asarray(image, dtype=np.float32)
    coefficients = dctn(array, type=2, norm="ortho")[:8, :8].reshape(-1)
    threshold = np.median(coefficients[1:])
    bits = coefficients > threshold
    value = np.uint64(0)
    for index, bit in enumerate(bits):
        if bool(bit):
            value |= np.uint64(1) << np.uint64(index)
    return value


def hamming_distance(left: int | np.uint64, right: int | np.uint64) -> int:
    return int(int(left) ^ int(right)).bit_count()


class UnionFind:
    def __init__(self, values: list[str]) -> None:
        self.parent = {value: value for value in values}
        self.rank = {value: 0 for value in values}

    def find(self, value: str) -> str:
        parent = self.parent[value]
        if parent != value:
            self.parent[value] = self.find(parent)
        return self.parent[value]

    def union(self, left: str, right: str) -> None:
        root_left, root_right = self.find(left), self.find(right)
        if root_left == root_right:
            return
        if self.rank[root_left] < self.rank[root_right]:
            root_left, root_right = root_right, root_left
        self.parent[root_right] = root_left
        if self.rank[root_left] == self.rank[root_right]:
            self.rank[root_left] += 1


@dataclass(frozen=True)
class Edge:
    left: str
    right: str
    criterion: str
    value: float | str


def exact_hash_edges(inventory: pd.DataFrame) -> list[Edge]:
    edges: list[Edge] = []
    for sha256, group in inventory.groupby("sha256", sort=False):
        identifiers = group["sample_id"].astype(str).tolist()
        for left, right in zip(identifiers, identifiers[1:]):
            edges.append(Edge(left, right, "sha256", str(sha256)))
    return edges


def pair_edges(inventory: pd.DataFrame) -> list[Edge]:
    if "pair_id" not in inventory.columns:
        return []
    edges: list[Edge] = []
    valid = inventory[inventory["pair_id"].notna() & (inventory["pair_id"].astype(str) != "")]
    for pair_id, group in valid.groupby("pair_id", sort=False):
        identifiers = group["sample_id"].astype(str).tolist()
        for left, right in zip(identifiers, identifiers[1:]):
            edges.append(Edge(left, right, "pair_id", str(pair_id)))
    return edges


def threshold_edges_blockwise(
    sample_ids: list[str],
    hashes: np.ndarray,
    embeddings: np.ndarray | None,
    hamming_max: int = 6,
    cosine_min: float = 0.985,
    block_size: int = 2048,
) -> list[Edge]:
    """Create verified threshold edges with bounded working memory.

    This exact blockwise routine is deterministic. For the full corpus, run blocks on a
    GPU-backed NumPy-compatible environment or provide candidate pairs from FAISS and
    recheck every candidate with this function's distance criteria.
    """
    hashes = np.asarray(hashes, dtype=np.uint64)
    if embeddings is not None:
        embeddings = np.asarray(embeddings, dtype=np.float32)
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True).clip(1e-12)
    edges: list[Edge] = []
    count = len(sample_ids)
    for start_left in range(0, count, block_size):
        stop_left = min(count, start_left + block_size)
        for start_right in range(start_left, count, block_size):
            stop_right = min(count, start_right + block_size)
            for left_index in range(start_left, stop_left):
                right_begin = max(left_index + 1, start_right)
                for right_index in range(right_begin, stop_right):
                    distance = hamming_distance(hashes[left_index], hashes[right_index])
                    if distance <= hamming_max:
                        edges.append(
                            Edge(sample_ids[left_index], sample_ids[right_index], "phash", float(distance))
                        )
                        continue
                    if embeddings is not None:
                        similarity = float(embeddings[left_index] @ embeddings[right_index])
                        if similarity >= cosine_min:
                            edges.append(
                                Edge(sample_ids[left_index], sample_ids[right_index], "dinov2_cosine", similarity)
                            )
    return edges


def connected_group_manifest(inventory: pd.DataFrame, edges: list[Edge]) -> pd.DataFrame:
    identifiers = inventory["sample_id"].astype(str).tolist()
    union_find = UnionFind(identifiers)
    for edge in edges:
        union_find.union(edge.left, edge.right)
    components: dict[str, list[str]] = {}
    for identifier in identifiers:
        components.setdefault(union_find.find(identifier), []).append(identifier)
    ordered = sorted(components.values(), key=lambda values: min(values))
    group_by_sample: dict[str, str] = {}
    for index, values in enumerate(ordered, start=1):
        group_id = f"G{index:06d}"
        for value in values:
            group_by_sample[value] = group_id
    result = inventory.copy()
    result["group_id"] = result["sample_id"].astype(str).map(group_by_sample)
    return result


def audit_cross_partition_overlap(manifest: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for outer_fold, fold in manifest.groupby("outer_fold"):
        roles = sorted(fold["role"].unique())
        for left_index, left_role in enumerate(roles):
            left_groups = set(fold.loc[fold["role"] == left_role, "group_id"].astype(str))
            for right_role in roles[left_index + 1 :]:
                right_groups = set(fold.loc[fold["role"] == right_role, "group_id"].astype(str))
                rows.append(
                    {
                        "outer_fold": int(outer_fold),
                        "left_role": left_role,
                        "right_role": right_role,
                        "overlap_groups": len(left_groups & right_groups),
                    }
                )
    return pd.DataFrame(rows)
