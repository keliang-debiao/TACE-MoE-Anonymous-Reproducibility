from __future__ import annotations

import math
from typing import Callable

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)


def expected_calibration_error(
    labels: np.ndarray,
    probabilities: np.ndarray,
    bins: int = 15,
    adaptive: bool = False,
) -> float:
    labels = np.asarray(labels, dtype=float)
    probabilities = np.asarray(probabilities, dtype=float)
    if adaptive:
        order = np.argsort(probabilities, kind="mergesort")
        groups = np.array_split(order, bins)
    else:
        edges = np.linspace(0.0, 1.0, bins + 1)
        assignment = np.clip(np.digitize(probabilities, edges[1:-1], right=False), 0, bins - 1)
        groups = [np.flatnonzero(assignment == index) for index in range(bins)]
    total = max(1, labels.size)
    value = 0.0
    for indices in groups:
        if len(indices) == 0:
            continue
        accuracy = labels[indices].mean()
        confidence = probabilities[indices].mean()
        value += len(indices) / total * abs(accuracy - confidence)
    return float(value)


def classwise_ece(labels: np.ndarray, probabilities: np.ndarray, bins: int = 15) -> float:
    labels = np.asarray(labels, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    positive = expected_calibration_error(labels, probabilities, bins=bins)
    negative = expected_calibration_error(1 - labels, 1.0 - probabilities, bins=bins)
    return float((positive + negative) / 2.0)


def binary_metrics(
    labels: np.ndarray,
    probabilities: np.ndarray,
    threshold: float = 0.5,
    bins: int = 15,
) -> dict[str, float]:
    labels = np.asarray(labels, dtype=int)
    probabilities = np.clip(np.asarray(probabilities, dtype=float), 1e-7, 1.0 - 1e-7)
    predictions = (probabilities >= threshold).astype(int)
    has_two_classes = np.unique(labels).size == 2
    return {
        "accuracy": float(accuracy_score(labels, predictions)),
        "precision": float(precision_score(labels, predictions, zero_division=0)),
        "recall": float(recall_score(labels, predictions, zero_division=0)),
        "f1": float(f1_score(labels, predictions, zero_division=0)),
        "auroc": float(roc_auc_score(labels, probabilities)) if has_two_classes else float("nan"),
        "auprc": float(average_precision_score(labels, probabilities)) if has_two_classes else float("nan"),
        "nll": float(log_loss(labels, probabilities, labels=[0, 1])),
        "brier": float(brier_score_loss(labels, probabilities)),
        "ece": expected_calibration_error(labels, probabilities, bins=bins),
        "adaptive_ece": expected_calibration_error(labels, probabilities, bins=bins, adaptive=True),
        "classwise_ece": classwise_ece(labels, probabilities, bins=bins),
    }


def reliability_rows(labels: np.ndarray, probabilities: np.ndarray, bins: int = 15) -> list[dict[str, float | int]]:
    labels = np.asarray(labels, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    edges = np.linspace(0.0, 1.0, bins + 1)
    assignment = np.clip(np.digitize(probabilities, edges[1:-1], right=False), 0, bins - 1)
    rows: list[dict[str, float | int]] = []
    for index in range(bins):
        selected = assignment == index
        rows.append(
            {
                "bin": index + 1,
                "lower": float(edges[index]),
                "upper": float(edges[index + 1]),
                "count": int(selected.sum()),
                "mean_probability": float(probabilities[selected].mean()) if selected.any() else float("nan"),
                "positive_fraction": float(labels[selected].mean()) if selected.any() else float("nan"),
            }
        )
    return rows


def risk_coverage_curve(
    labels: np.ndarray,
    probabilities: np.ndarray,
    confidence: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float]:
    labels = np.asarray(labels, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    confidence = np.asarray(confidence, dtype=float)
    order = np.argsort(-confidence, kind="mergesort")
    errors = ((probabilities[order] >= 0.5).astype(int) != labels[order]).astype(float)
    cumulative_risk = np.cumsum(errors) / np.arange(1, errors.size + 1)
    coverage = np.arange(1, errors.size + 1, dtype=float) / errors.size
    aurc = float(np.trapezoid(cumulative_risk, coverage))
    return coverage, cumulative_risk, aurc


def entropy_confidence(probabilities: np.ndarray) -> np.ndarray:
    p = np.clip(np.asarray(probabilities, dtype=float), 1e-12, 1.0 - 1e-12)
    entropy = -(p * np.log(p) + (1 - p) * np.log(1 - p))
    return 1.0 - entropy / math.log(2.0)


METRIC_FUNCTIONS: dict[str, Callable[[np.ndarray, np.ndarray], float]] = {
    "accuracy": lambda y, p: binary_metrics(y, p)["accuracy"],
    "f1": lambda y, p: binary_metrics(y, p)["f1"],
    "auroc": lambda y, p: binary_metrics(y, p)["auroc"],
    "ece": lambda y, p: binary_metrics(y, p)["ece"],
}
