from __future__ import annotations

import math
from typing import Any

import torch
from torch import nn

from .evidence import haar_high_frequency, nearest_patch_residual, pixel_statistics


class ConvStage(nn.Module):
    def __init__(self, input_channels: int, output_channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(input_channels, output_channels, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(output_channels),
            nn.GELU(),
            nn.Conv2d(output_channels, output_channels, 3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(output_channels),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class FourStageEncoder(nn.Module):
    def __init__(self, input_channels: int, channels: list[int], output_dim: int) -> None:
        super().__init__()
        if len(channels) != 4:
            raise ValueError("Evidence encoder requires four channel widths")
        stages: list[nn.Module] = []
        current = input_channels
        for width in channels:
            stages.append(ConvStage(current, width))
            current = width
        self.stages = nn.Sequential(*stages)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.projection = nn.Linear(channels[-1], output_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.projection(self.pool(self.stages(x)).flatten(1))


class RGBEncoder(nn.Module):
    def __init__(
        self,
        name: str,
        pretrained: bool,
        output_dim: int,
        compact_channels: list[int],
    ) -> None:
        super().__init__()
        self.name = name
        if name == "compact":
            self.backbone = FourStageEncoder(3, compact_channels, output_dim)
            self.projection = nn.Identity()
        else:
            try:
                import timm
            except ImportError as exc:
                raise RuntimeError("timm is required for the manuscript RGB backbone") from exc
            self.backbone = timm.create_model(name, pretrained=pretrained, num_classes=0, global_pool="avg")
            feature_dim = int(self.backbone.num_features)
            self.projection = nn.Linear(feature_dim, output_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.projection(self.backbone(x))


def bernoulli_entropy(probability: torch.Tensor) -> torch.Tensor:
    p = probability.clamp(1e-7, 1.0 - 1e-7)
    return -(p * p.log() + (1.0 - p) * (1.0 - p).log())


class TACEMoE(nn.Module):
    """Temperature-Calibrated Adaptive Cross-Evidence Mixture of Experts."""

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__()
        model_config = config["model"]
        evidence_config = config.get("evidence", {})
        representation_dim = int(model_config["representation_dim"])
        channels = [int(value) for value in model_config["evidence_channels"]]
        self.npr_radius = int(evidence_config.get("npr_radius", 2))

        self.rgb_encoder = RGBEncoder(
            str(model_config["rgb_backbone"]),
            bool(model_config.get("rgb_pretrained", True)),
            representation_dim,
            channels,
        )
        self.npr_encoder = FourStageEncoder(3, channels, representation_dim)
        self.frequency_encoder = FourStageEncoder(9, channels, representation_dim)
        self.expert_heads = nn.ModuleList([nn.Linear(representation_dim, 1) for _ in range(3)])
        self.value_projections = nn.ModuleList(
            [nn.Linear(representation_dim, representation_dim) for _ in range(3)]
        )
        context = str(model_config.get("router_context", "pixel_statistics"))
        if context not in {"pixel_statistics", "evidence_only"}:
            raise ValueError("Final model supports pixel_statistics or evidence_only routing")
        self.router_context = context
        router_input = representation_dim * 3 + 3 + (6 if context == "pixel_statistics" else 0)
        self.router = nn.Sequential(
            nn.Linear(router_input, int(model_config["router_hidden_dim"])),
            nn.GELU(),
            nn.Dropout(float(model_config["router_dropout"])),
            nn.Linear(int(model_config["router_hidden_dim"]), 3),
        )
        self.final_head = nn.Linear(representation_dim, 1)
        self.register_buffer("rgb_mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("rgb_std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))
        self.register_buffer("frequency_mean", torch.zeros(1, 9, 1, 1))
        self.register_buffer("frequency_std", torch.ones(1, 9, 1, 1))
        self._initialize_new_layers()

    def _initialize_new_layers(self) -> None:
        modules = [self.npr_encoder, self.frequency_encoder, self.expert_heads, self.value_projections, self.router, self.final_head]
        if getattr(self.rgb_encoder, "name", None) == "compact":
            modules.append(self.rgb_encoder)
        for root in modules:
            for layer in root.modules():
                if isinstance(layer, nn.Conv2d):
                    nn.init.kaiming_normal_(layer.weight, nonlinearity="relu")
                elif isinstance(layer, nn.Linear):
                    nn.init.xavier_uniform_(layer.weight)
                    if layer.bias is not None:
                        nn.init.zeros_(layer.bias)

    def set_frequency_statistics(self, mean: torch.Tensor, standard_deviation: torch.Tensor) -> None:
        if mean.numel() != 9 or standard_deviation.numel() != 9:
            raise ValueError("Frequency statistics must contain nine channels")
        self.frequency_mean.copy_(mean.reshape(1, 9, 1, 1))
        self.frequency_std.copy_(standard_deviation.reshape(1, 9, 1, 1).clamp_min(1e-6))

    def forward(self, pixels: torch.Tensor) -> dict[str, torch.Tensor]:
        if pixels.min().item() < -1e-5 or pixels.max().item() > 1.00001:
            raise ValueError("Model input must be RGB pixels scaled to [0,1]")
        rgb = (pixels - self.rgb_mean) / self.rgb_std
        npr = nearest_patch_residual(pixels, self.npr_radius)
        frequency = haar_high_frequency(pixels)
        frequency = (frequency - self.frequency_mean) / self.frequency_std.clamp_min(1e-6)

        representations = [
            self.rgb_encoder(rgb),
            self.npr_encoder(npr),
            self.frequency_encoder(frequency),
        ]
        expert_logits = torch.cat(
            [head(value) for head, value in zip(self.expert_heads, representations)], dim=1
        )
        expert_probabilities = expert_logits.sigmoid()
        expert_entropies = bernoulli_entropy(expert_probabilities)
        router_parts = [*representations, expert_entropies]
        if self.router_context == "pixel_statistics":
            router_parts.append(pixel_statistics(pixels))
        routing_weights = self.router(torch.cat(router_parts, dim=1)).softmax(dim=1)
        projected = torch.stack(
            [projection(value) for projection, value in zip(self.value_projections, representations)], dim=1
        )
        fused = (routing_weights.unsqueeze(-1) * projected).sum(dim=1)
        logits = self.final_head(fused).squeeze(1)
        probability = logits.sigmoid()
        weighted_uncertainty = (routing_weights * expert_entropies).sum(dim=1)
        confidence = 1.0 - (bernoulli_entropy(probability) + weighted_uncertainty) / (2.0 * math.log(2.0))
        return {
            "logits": logits,
            "probability": probability,
            "representations": torch.stack(representations, dim=1),
            "expert_logits": expert_logits,
            "expert_probabilities": expert_probabilities,
            "expert_entropies": expert_entropies,
            "routing_weights": routing_weights,
            "fused_representation": fused,
            "confidence": confidence.clamp(0.0, 1.0),
        }

    @property
    def trainable_parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters() if parameter.requires_grad)
