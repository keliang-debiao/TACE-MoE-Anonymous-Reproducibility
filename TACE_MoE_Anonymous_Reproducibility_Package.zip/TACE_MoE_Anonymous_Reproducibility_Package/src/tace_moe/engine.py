from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

from .losses import composite_loss
from .metrics import binary_metrics


@dataclass
class EarlyStopping:
    patience: int
    best: float = float("inf")
    bad_epochs: int = 0

    def update(self, value: float) -> bool:
        if value < self.best - 1e-8:
            self.best = value
            self.bad_epochs = 0
            return True
        self.bad_epochs += 1
        return False

    @property
    def should_stop(self) -> bool:
        return self.bad_epochs >= self.patience


def atomic_torch_save(value: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".pending")
    torch.save(value, temporary)
    os.replace(temporary, path)


def move_batch(batch: dict[str, Any], device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    return batch["pixels"].to(device, non_blocking=True), batch["label"].to(device, non_blocking=True)


def train_one_epoch(
    model: torch.nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    loss_config: dict[str, Any],
    device: torch.device,
    scaler: torch.amp.GradScaler | None = None,
    gradient_clip_norm: float = 5.0,
) -> dict[str, float]:
    model.train()
    totals: dict[str, float] = {}
    count = 0
    use_amp = scaler is not None and device.type == "cuda"
    for batch in loader:
        pixels, labels = move_batch(batch, device)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, enabled=use_amp):
            output = model(pixels)
            losses = composite_loss(output, labels, loss_config)
        if scaler is None:
            losses["total"].backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clip_norm)
            optimizer.step()
        else:
            scaler.scale(losses["total"]).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clip_norm)
            scaler.step(optimizer)
            scaler.update()
        batch_size = labels.numel()
        count += batch_size
        for name, value in losses.items():
            totals[name] = totals.get(name, 0.0) + float(value.detach()) * batch_size
    return {name: value / max(1, count) for name, value in totals.items()}


@torch.inference_mode()
def predict(
    model: torch.nn.Module,
    loader: DataLoader,
    device: torch.device,
) -> pd.DataFrame:
    model.eval()
    rows: list[dict[str, Any]] = []
    for batch in loader:
        pixels, labels = move_batch(batch, device)
        output = model(pixels)
        for index, sample_id in enumerate(batch["sample_id"]):
            rows.append(
                {
                    "sample_id": str(sample_id),
                    "group_id": str(batch["group_id"][index]),
                    "label": int(labels[index].item()),
                    "logit": float(output["logits"][index].cpu()),
                    "probability": float(output["probability"][index].cpu()),
                    "confidence": float(output["confidence"][index].cpu()),
                    "router_rgb": float(output["routing_weights"][index, 0].cpu()),
                    "router_npr": float(output["routing_weights"][index, 1].cpu()),
                    "router_frequency": float(output["routing_weights"][index, 2].cpu()),
                    "expert_rgb": float(output["expert_probabilities"][index, 0].cpu()),
                    "expert_npr": float(output["expert_probabilities"][index, 1].cpu()),
                    "expert_frequency": float(output["expert_probabilities"][index, 2].cpu()),
                    "entropy_rgb": float(output["expert_entropies"][index, 0].cpu()),
                    "entropy_npr": float(output["expert_entropies"][index, 1].cpu()),
                    "entropy_frequency": float(output["expert_entropies"][index, 2].cpu()),
                }
            )
    return pd.DataFrame(rows)


def evaluate_predictions(frame: pd.DataFrame, probability_column: str = "probability", bins: int = 15) -> dict[str, float]:
    return binary_metrics(
        frame["label"].to_numpy(), frame[probability_column].to_numpy(), bins=bins
    )


def write_json(value: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
