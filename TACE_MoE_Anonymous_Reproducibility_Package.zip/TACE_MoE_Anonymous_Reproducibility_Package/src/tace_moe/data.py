from __future__ import annotations

import hashlib
import random
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from PIL import Image, ImageEnhance, ImageOps
from torch.utils.data import Dataset


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}


def stable_sample_id(dataset: str, relative_path: str) -> str:
    value = f"{dataset}:{relative_path.replace('\\\\', '/')}".encode("utf-8")
    return hashlib.sha256(value).hexdigest()[:24]


def resize_shorter_side(image: Image.Image, short_side: int) -> Image.Image:
    width, height = image.size
    scale = short_side / min(width, height)
    target = (max(1, round(width * scale)), max(1, round(height * scale)))
    return image.resize(target, Image.Resampling.BICUBIC)


def center_crop(image: Image.Image, size: int) -> Image.Image:
    width, height = image.size
    left = max(0, (width - size) // 2)
    top = max(0, (height - size) // 2)
    return image.crop((left, top, left + size, top + size))


def random_resized_crop(
    image: Image.Image,
    size: int,
    scale_range: tuple[float, float],
    ratio_range: tuple[float, float],
) -> Image.Image:
    width, height = image.size
    area = width * height
    for _ in range(10):
        target_area = area * random.uniform(*scale_range)
        aspect = random.uniform(*ratio_range)
        crop_width = int(round((target_area * aspect) ** 0.5))
        crop_height = int(round((target_area / aspect) ** 0.5))
        if 0 < crop_width <= width and 0 < crop_height <= height:
            left = random.randint(0, width - crop_width)
            top = random.randint(0, height - crop_height)
            crop = image.crop((left, top, left + crop_width, top + crop_height))
            return crop.resize((size, size), Image.Resampling.BICUBIC)
    return center_crop(resize_shorter_side(image, size), size)


def color_jitter(image: Image.Image, magnitude: float) -> Image.Image:
    for enhancer in (ImageEnhance.Brightness, ImageEnhance.Contrast, ImageEnhance.Color):
        factor = random.uniform(1.0 - magnitude, 1.0 + magnitude)
        image = enhancer(image).enhance(factor)
    return image


def image_to_tensor(image: Image.Image) -> torch.Tensor:
    array = np.asarray(image, dtype=np.float32) / 255.0
    if array.ndim == 2:
        array = np.repeat(array[..., None], 3, axis=2)
    if array.shape[2] == 4:
        array = array[:, :, :3]
    return torch.from_numpy(array.transpose(2, 0, 1).copy())


class ImageManifestDataset(Dataset[dict[str, Any]]):
    def __init__(
        self,
        manifest: pd.DataFrame,
        root: str | Path,
        preprocessing: dict[str, Any],
        training: bool,
    ) -> None:
        required = {"sample_id", "relative_path", "label"}
        missing = required.difference(manifest.columns)
        if missing:
            raise ValueError(f"Manifest missing columns: {sorted(missing)}")
        self.manifest = manifest.reset_index(drop=True).copy()
        self.root = Path(root)
        self.preprocessing = preprocessing
        self.training = training

    def __len__(self) -> int:
        return len(self.manifest)

    def __getitem__(self, index: int) -> dict[str, Any]:
        row = self.manifest.iloc[index]
        path = self.root / str(row["relative_path"])
        with Image.open(path) as source:
            image = ImageOps.exif_transpose(source).convert("RGB")
        crop_size = int(self.preprocessing["crop_size"])
        if self.training:
            image = random_resized_crop(
                image,
                crop_size,
                tuple(map(float, self.preprocessing["train_scale"])),
                tuple(map(float, self.preprocessing["train_ratio"])),
            )
            if random.random() < float(self.preprocessing["horizontal_flip_probability"]):
                image = ImageOps.mirror(image)
            image = color_jitter(image, float(self.preprocessing["color_jitter"]))
        else:
            image = center_crop(
                resize_shorter_side(image, int(self.preprocessing["eval_short_side"])), crop_size
            )
        return {
            "pixels": image_to_tensor(image),
            "label": torch.tensor(float(row["label"]), dtype=torch.float32),
            "sample_id": str(row["sample_id"]),
            "group_id": str(row.get("group_id", row["sample_id"])),
        }


def discover_images(root: str | Path) -> list[Path]:
    root = Path(root)
    return sorted(path for path in root.rglob("*") if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES)


def infer_label(path: Path, aliases: dict[str, list[str]]) -> int:
    components = {part.lower() for part in path.parts}
    ai_aliases = {value.lower() for value in aliases["ai"]}
    human_aliases = {value.lower() for value in aliases["human"]}
    ai_match = bool(components & ai_aliases)
    human_match = bool(components & human_aliases)
    if ai_match == human_match:
        raise ValueError(f"Unable to infer a unique label from path: {path}")
    return 1 if ai_match else 0
