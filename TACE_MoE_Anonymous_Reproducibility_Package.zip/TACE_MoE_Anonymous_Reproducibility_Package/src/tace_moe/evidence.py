from __future__ import annotations

from itertools import product

import torch
import torch.nn.functional as F


def nearest_patch_residual(x: torch.Tensor, radius: int = 2) -> torch.Tensor:
    """Return nearest-RGB-neighbor residuals with reflection padding.

    Args:
        x: Float tensor shaped [batch, 3, height, width] on a common scale.
        radius: Search radius; the manuscript setting is two.
    """
    if x.ndim != 4 or x.shape[1] != 3:
        raise ValueError("NPR input must have shape [batch, 3, height, width]")
    if radius < 1:
        raise ValueError("radius must be positive")
    height, width = x.shape[-2:]
    padded = F.pad(x, (radius, radius, radius, radius), mode="reflect")
    best_distance = torch.full_like(x[:, :1], float("inf"))
    best_neighbor = torch.zeros_like(x)
    for dy, dx in product(range(-radius, radius + 1), repeat=2):
        if dy == 0 and dx == 0:
            continue
        y0 = radius + dy
        x0 = radius + dx
        candidate = padded[:, :, y0 : y0 + height, x0 : x0 + width]
        distance = (x - candidate).square().sum(dim=1, keepdim=True)
        update = distance < best_distance
        best_distance = torch.where(update, distance, best_distance)
        best_neighbor = torch.where(update.expand_as(x), candidate, best_neighbor)
    return x - best_neighbor


def haar_high_frequency(x: torch.Tensor) -> torch.Tensor:
    """Compute one-level normalized Haar LH, HL, and HH maps per channel."""
    if x.ndim != 4 or x.shape[1] != 3:
        raise ValueError("Wavelet input must have shape [batch, 3, height, width]")
    kernels = torch.tensor(
        [
            [[1.0, 1.0], [-1.0, -1.0]],
            [[1.0, -1.0], [1.0, -1.0]],
            [[1.0, -1.0], [-1.0, 1.0]],
        ],
        dtype=x.dtype,
        device=x.device,
    ).div_(2.0)
    weight = kernels[:, None].repeat(x.shape[1], 1, 1, 1)
    return F.conv2d(x, weight, stride=2, groups=x.shape[1])


def pixel_statistics(x: torch.Tensor) -> torch.Tensor:
    """Return RGB means followed by RGB standard deviations for [0,1] crops."""
    if x.ndim != 4 or x.shape[1] != 3:
        raise ValueError("Pixel-statistics input must have shape [batch, 3, height, width]")
    means = x.mean(dim=(2, 3))
    standard_deviations = x.std(dim=(2, 3), unbiased=False)
    return torch.cat([means, standard_deviations], dim=1)


def standardize_frequency(
    frequency: torch.Tensor,
    mean: torch.Tensor | None = None,
    standard_deviation: torch.Tensor | None = None,
) -> torch.Tensor:
    if mean is None:
        mean = frequency.mean(dim=(0, 2, 3), keepdim=True)
    if standard_deviation is None:
        standard_deviation = frequency.std(dim=(0, 2, 3), keepdim=True, unbiased=False)
    return (frequency - mean) / standard_deviation.clamp_min(1e-6)
