from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F


class TemperatureScaler:
    def __init__(self, initial_temperature: float = 1.0) -> None:
        if initial_temperature <= 0:
            raise ValueError("initial_temperature must be positive")
        self.log_temperature = float(np.log(initial_temperature))

    @property
    def temperature(self) -> float:
        return float(np.exp(self.log_temperature))

    def fit(self, logits: np.ndarray, labels: np.ndarray, maximum_iterations: int = 50) -> "TemperatureScaler":
        logit_tensor = torch.as_tensor(logits, dtype=torch.float64).reshape(-1)
        label_tensor = torch.as_tensor(labels, dtype=torch.float64).reshape(-1)
        if logit_tensor.numel() != label_tensor.numel() or logit_tensor.numel() == 0:
            raise ValueError("Calibration logits and labels must be non-empty and aligned")
        parameter = torch.tensor([self.log_temperature], dtype=torch.float64, requires_grad=True)
        optimizer = torch.optim.LBFGS(
            [parameter], lr=0.25, max_iter=maximum_iterations, line_search_fn="strong_wolfe"
        )

        def closure() -> torch.Tensor:
            optimizer.zero_grad(set_to_none=True)
            temperature = parameter.exp().clamp(0.05, 20.0)
            loss = F.binary_cross_entropy_with_logits(logit_tensor / temperature, label_tensor)
            loss.backward()
            return loss

        optimizer.step(closure)
        self.log_temperature = float(parameter.detach().clamp(np.log(0.05), np.log(20.0)).item())
        return self

    def transform_logits(self, logits: np.ndarray) -> np.ndarray:
        return np.asarray(logits, dtype=float) / self.temperature

    def predict_proba(self, logits: np.ndarray) -> np.ndarray:
        scaled = self.transform_logits(logits)
        return 1.0 / (1.0 + np.exp(-np.clip(scaled, -60.0, 60.0)))

    def to_dict(self) -> dict[str, float]:
        return {"temperature": self.temperature, "log_temperature": self.log_temperature}

    @classmethod
    def from_dict(cls, value: dict[str, float]) -> "TemperatureScaler":
        scaler = cls(float(value["temperature"]))
        return scaler
